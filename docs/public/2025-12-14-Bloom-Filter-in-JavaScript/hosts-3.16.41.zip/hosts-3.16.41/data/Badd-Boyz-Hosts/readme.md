# Source domain history

This page is only occasionally refreshed.

![History of the number of domains from this source](./stats.png)

The file `stats.out` in this folder contains raw data for this graph.
