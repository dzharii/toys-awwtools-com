(()=>{var I=[{id:"burn-page",version:"1.0.0",sdkVersion:"1.0",name:"Burn the Page",description:"Char a selected surface and watch its embers rise.",category:"Transform",tags:["burn","playful"],scope:"element",interaction:"click",intensity:"medium",icon:"M4 5h24v23H4z",color:"#fb923c",source:{researchId:"cr004-burn-page",name:"Burn the Web",author:"James P. Burke",url:"https://github.com/JamesPBurke/burnit",relationship:"Independently reconstructed behavioral inspiration; no source or assets reused",license:"Project-owned implementation, icon and procedural audio; original source license not relied upon"},enabled:!0,status:"review-pending",activation:"replace",capabilities:{reducedMotion:!0,audio:!0,pause:!1},lifetime:{overlap:"replace",animationMs:2300,residueMs:0,class:"repeatable"},iconSvg:`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32"><defs><linearGradient id="ICON-g" x1="0" y1="0" x2="1" y2="1"><stop stop-color="#ffd36a"/><stop offset="1" stop-color="#ef532e"/></linearGradient></defs><path d="M17 2c4 9-2 8 3 13 2-2 3-3 3-5 7 9 7 20-7 21C2 30 3 18 10 11c-1 6 2 5 4 8 4-6-2-10 3-17Z" fill="url(#ICON-g)"/><path d="M16 17c1 5 6 5 4 10-1 4-9 4-9-1 0-4 4-5 5-9Z" fill="#fff2ad"/></svg>
`,audioProfile:{activate:{layers:[{wave:"noise",frequency:500,cutoff:1600,duration:0.2,gain:0.045}]},crackle:{layers:[{wave:"noise",frequency:900,cutoff:2100,duration:0.6,gain:0.035,attack:0.08},{wave:"noise",frequency:600,cutoff:1500,duration:0.17,delay:0.12,gain:0.025}]}}},{id:"celebration-cannon",version:"1.0.0",sdkVersion:"1.0",name:"Celebration Cannon",description:"Fire confetti and ribbons around a selected element.",category:"Play",tags:["celebration","playful"],scope:"element",interaction:"click",intensity:"medium",icon:"M4 5h24v23H4z",color:"#fbbf24",source:{researchId:"cr004-celebration-cannon",name:"Web Pranks",author:"steveja42",url:"https://github.com/steveja42/webpranks",relationship:"Independently reconstructed behavioral inspiration; no source or assets reused",license:"Project-owned implementation, icon and procedural audio; original source license not relied upon"},enabled:!0,status:"review-pending",activation:"replace",capabilities:{reducedMotion:!0,audio:!0,pause:!1},lifetime:{overlap:"replace",animationMs:2300,residueMs:0,class:"repeatable"},iconSvg:`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32"><defs><linearGradient id="ICON-g" x1="0" y1="0" x2="1" y2="1"><stop stop-color="#ffc0d7"/><stop offset="1" stop-color="#ed688a"/></linearGradient></defs><path d="m4 29 6-21 15 14Z" fill="url(#ICON-g)"/><path d="m7 20 8 6M9 13l11 10" stroke="#ffe59f" stroke-width="3"/><path d="m17 10 4-6M23 15l7-1M13 5l-1-3" stroke="#40c9bd" stroke-width="2.5" stroke-linecap="round"/><circle cx="27" cy="5" r="2" fill="#fa8caa"/><path d="m24 25 3 4M6 5 3 3" stroke="#b695f6" stroke-width="2.5"/></svg>
`,audioProfile:{activate:{layers:[{wave:"noise",frequency:900,cutoff:2400,duration:0.14,gain:0.07},{wave:"sine",frequency:350,endFrequency:100,duration:0.12,gain:0.08},{wave:"triangle",frequency:660,endFrequency:880,duration:0.25,gain:0.025,delay:0.07}]}}},{id:"color-splash",version:"1.0.0",sdkVersion:"1.0",name:"Color Splash",description:"Throw a glossy burst of paint onto a selected page region.",category:"Transform",tags:["color","original","playful"],scope:"element",interaction:"click",intensity:"low",icon:"M6 6h20v20h-20z",color:"#eb809b",source:{researchId:"candidate-color-splash",name:"DevBubba collection: Color Drop",author:"DevBubba (historical lead, unverified)",url:"https://devbubba.github.io/Bookmarklets/",relationship:"Independent implementation of described concept; no source or assets reused",license:"Project-owned original code, icons and synthesized audio; historical source license unverified"},enabled:!0,status:"review-pending",activation:"replace",capabilities:{reducedMotion:!0,audio:!0,pause:!1},lifetime:{class:"repeatable",overlap:"replace",animationMs:1400,residueMs:300},iconSvg:`<svg viewBox="0 0 32 32" xmlns="http://www.w3.org/2000/svg"><defs><linearGradient id="ICON-g" x1="0" y1="0" x2=".7" y2="1"><stop stop-color="#faafbf"/><stop offset="1" stop-color="#e56694"/></linearGradient></defs><g stroke="#344559" stroke-width=".7" stroke-linecap="round" stroke-linejoin="round"><path d="M15 3 19 9 25 6 24 13 30 16 24 20 26 26 19 24 15 30 12 24 5 26 7 19 2 15 9 12 8 6 13 9Z" fill="url(#ICON-g)"/><ellipse cx="15" cy="15" rx="7" ry="6" fill="#f8aabc" stroke="none"/><path d="m11 12 3-2 3 1" fill="none" stroke="#fff4ef" stroke-width="2"/><circle cx="28" cy="5" r="2" fill="#6ac7c4"/><circle cx="3" cy="28" r="2" fill="#f6c161"/></g></svg>
`,audioProfile:{activate:{layers:[{wave:"noise",frequency:300,duration:0.23,gain:0.075,cutoff:850},{wave:"sine",frequency:210,endFrequency:80,duration:0.15,gain:0.065}]}}},{id:"depth-page",version:"1.0.0",sdkVersion:"1.0",name:"Depth Page",description:"Lift page cards into a layered, pointer-responsive perspective.",category:"Environment",tags:["depth","original","playful"],scope:"document",interaction:"pointer",intensity:"low",icon:"M6 6h20v20h-20z",color:"#79a7e8",source:{researchId:"candidate-depth-page",name:"DevBubba collection: 3D Webpage",author:"DevBubba (historical lead, unverified)",url:"https://devbubba.github.io/Bookmarklets/",relationship:"Independent implementation of described concept; no source or assets reused",license:"Project-owned original code, icons and synthesized audio; historical source license unverified"},enabled:!0,status:"review-pending",activation:"replace",capabilities:{reducedMotion:!0,audio:!0,pause:!1},lifetime:{class:"simulation",overlap:"replace",animationMs:1000,residueMs:0},iconSvg:`<svg viewBox="0 0 32 32" xmlns="http://www.w3.org/2000/svg"><defs><linearGradient id="ICON-g" x1="0" y1="0" x2=".7" y2="1"><stop stop-color="#e0efff"/><stop offset="1" stop-color="#76a8df"/></linearGradient></defs><g stroke="#344559" stroke-width=".7" stroke-linecap="round" stroke-linejoin="round"><path d="m5 20 11-5 11 5-11 6z" fill="#629ad0"/><path d="m5 14 11-5 11 5-11 6z" fill="#9abde8"/><path d="m5 8 11-5 11 5-11 6z" fill="url(#ICON-g)"/><path d="m11 7 9 1-4 3" fill="none" stroke="#ffffff"/></g></svg>
`,audioProfile:{activate:{layers:[{wave:"triangle",frequency:230,endFrequency:460,duration:0.24,gain:0.045}]}}},{id:"disintegrate",version:"1.0.0",sdkVersion:"1.0",name:"Disintegrate",description:"Dissolve a complete surface into drifting fragments.",category:"Transform",tags:["disintegrate","playful"],scope:"element",interaction:"click",intensity:"medium",icon:"M4 5h24v23H4z",color:"#c4b5fd",source:{researchId:"cr004-disintegrate",name:"Disintegrate",author:"Zach Saucier",url:"https://github.com/ZachSaucier/Disintegrate",relationship:"Independently reconstructed behavioral inspiration; no source or assets reused",license:"Project-owned implementation, icon and procedural audio; original source license not relied upon"},enabled:!0,status:"review-pending",activation:"replace",capabilities:{reducedMotion:!0,audio:!0,pause:!1},lifetime:{overlap:"replace",animationMs:2100,residueMs:0,class:"repeatable"},iconSvg:`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32"><defs><linearGradient id="ICON-g" x1="0" y1="0" x2="1" y2="1"><stop stop-color="#c9b7f6"/><stop offset="1" stop-color="#8065cb"/></linearGradient></defs><path d="M3 6h17v21H3z" fill="url(#ICON-g)"/><path d="M3 6h13v5H3z" fill="#e9e0ff"/><rect x="21" y="4" width="5" height="5" rx="1" fill="#b099f4"/><rect x="23" y="13" width="6" height="5" rx="1" fill="#d0bffa"/><rect x="20" y="22" width="4" height="4" rx="1" fill="#977ae3"/><rect x="28" y="24" width="3" height="3" fill="#bba3ec"/></svg>
`,audioProfile:{activate:{layers:[{wave:"noise",frequency:1300,cutoff:2700,duration:0.65,gain:0.045,attack:0.06},{wave:"triangle",frequency:370,endFrequency:180,duration:0.3,gain:0.025}]}}},{id:"flashlight",version:"1.2.0",sdkVersion:"1.0",name:"Flashlight",description:"Lights out. Follow your own circle of light.",category:"Light",tags:["light","fun"],scope:"viewport",interaction:"pointer",intensity:"low",icon:"M4 3h12l-3 7v11H7V10zM19 4l3-2m-3 6h3",color:"#86cbb7",source:{researchId:"candidate-flashlight",name:"Bookmarklets / Flashlight",author:"Krazete",url:"https://github.com/Krazete/bookmarklets",relationship:"inspired-by",license:"No source or assets reused; original license unverified"},enabled:!0,status:"review-pending",activation:"replace",capabilities:{reducedMotion:!0,audio:!0,pause:!1},lifetime:{class:"continuous",overlap:"replace",animationMs:1000,residueMs:200},iconSvg:`<svg viewBox="0 0 32 32" xmlns="http://www.w3.org/2000/svg"><defs><linearGradient id="ICON-g" x1="0" y1="0" x2=".7" y2="1"><stop stop-color="#ffe79b"/><stop offset="1" stop-color="#e2a52a"/></linearGradient></defs><g stroke="#344559" stroke-width=".7" stroke-linecap="round" stroke-linejoin="round"><path d="m7 18 13-13 7 7-13 13z" fill="url(#ICON-g)"/><path d="m18 7 3-3 7 7-3 3z" fill="#44536b"/><path d="m3 18 7-2 8 8-2 7z" fill="#45556b"/><ellipse cx="10" cy="24" rx="5" ry="7" transform="rotate(-45 10 24)" fill="#fff2ba"/><ellipse cx="10" cy="24" rx="3" ry="5" transform="rotate(-45 10 24)" fill="#fffdf2" stroke="none"/><path d="m17 12 3 3" stroke="#42516a" stroke-width="3"/></g></svg>
`,audioProfile:{activate:{layers:[{wave:"noise",frequency:400,duration:0.022,gain:0.04,cutoff:1600},{wave:"triangle",frequency:650,duration:0.04,gain:0.015,endFrequency:400}]}}},{id:"glass-shatter",version:"1.2.0",sdkVersion:"1.0",name:"Shatter",description:"Turn a comment into a shower of glass shards.",category:"Fracture",tags:["fracture","fun","break","smash","glass"],scope:"element",interaction:"click",intensity:"medium",icon:"M4 3l7 6-2 6 7 6M20 3l-9 6 8 3-3 9M3 16l6-1",color:"#83bed9",source:{researchId:"candidate-glass-shatter",name:"Fracture",author:"Aaron Beall",url:"https://github.com/aaronbeall/fracture",relationship:"inspired-by",license:"No source or assets reused; original license unverified"},enabled:!0,status:"review-pending",activation:"replace",capabilities:{reducedMotion:!0,audio:!0,pause:!1},lifetime:{class:"repeatable",overlap:"replace",animationMs:2000,residueMs:200},iconSvg:`<svg viewBox="0 0 32 32" xmlns="http://www.w3.org/2000/svg"><defs><linearGradient id="ICON-g" x1="0" y1="0" x2=".7" y2="1"><stop stop-color="#b8ecff"/><stop offset="1" stop-color="#4499d0"/></linearGradient></defs><g stroke="#344559" stroke-width=".7" stroke-linecap="round" stroke-linejoin="round"><path d="m4 6 9 3-5 8zM18 3l10 2-9 9zM16 15l11 2-5 10zM10 20l5 5-10 4z" fill="url(#ICON-g)"/><path d="m6 7 3 7m12-9-1 6m-2 8 4 4" fill="none" stroke="#eefcff" stroke-width="1.4"/></g></svg>
`,audioProfile:{activate:{layers:[{wave:"noise",frequency:1200,duration:0.09,gain:0.085,cutoff:4200},{wave:"triangle",frequency:1700,duration:0.12,gain:0.03,endFrequency:700}]},scatter:{layers:[{wave:"triangle",frequency:2100,duration:0.12,gain:0.016,delay:0,endFrequency:1680},{wave:"triangle",frequency:3300,duration:0.12,gain:0.016,delay:0.05,endFrequency:2640},{wave:"triangle",frequency:1400,duration:0.12,gain:0.016,delay:0.1,endFrequency:1120},{wave:"triangle",frequency:2700,duration:0.12,gain:0.016,delay:0.15000000000000002,endFrequency:2160}]}}},{id:"gravity-collapse",version:"1.2.0",sdkVersion:"1.0",name:"Gravity",description:"Let the visible page drop. Watch it bounce.",category:"Physics",tags:["physics","fun"],scope:"document",interaction:"automatic",intensity:"medium",icon:"M5 5h14M12 3v12m-4-4 4 4 4-4M5 21h14",color:"#bea2ed",source:{researchId:"candidate-gravity-collapse",name:"Google Gravity",author:"Mr.doob (Ricardo Cabello)",url:"https://mrdoob.com/projects/chromeexperiments/google-gravity/",relationship:"inspired-by",license:"No source or assets reused; original license unverified"},enabled:!0,status:"review-pending",activation:"replace",capabilities:{reducedMotion:!0,audio:!0,pause:!1},lifetime:{class:"simulation",overlap:"replace",animationMs:1000,residueMs:200},iconSvg:`<svg viewBox="0 0 32 32" xmlns="http://www.w3.org/2000/svg"><defs><linearGradient id="ICON-g" x1="0" y1="0" x2=".7" y2="1"><stop stop-color="#c1ccd4"/><stop offset="1" stop-color="#566474"/></linearGradient></defs><g stroke="#344559" stroke-width=".7" stroke-linecap="round" stroke-linejoin="round"><ellipse cx="16" cy="28" rx="11" ry="2" fill="#253749" opacity=".12" stroke="none"/><path d="m9 12 14 0 5 14c-6 3-18 3-24 0z" fill="url(#ICON-g)"/><circle cx="16" cy="9" r="4" fill="none" stroke="#627387" stroke-width="2.5"/><path d="M11 16 8 24" stroke="#e6f0f6" stroke-width="2"/><path d="M5 3v6m22-6v6" stroke="#7fc8df" stroke-width="2"/></g></svg>
`,audioProfile:{activate:{layers:[{wave:"sine",frequency:200,duration:0.15,gain:0.05,endFrequency:90}]},collision:{layers:[{wave:"sine",frequency:110,duration:0.12,gain:0.1,endFrequency:40},{wave:"noise",frequency:100,duration:0.055,gain:0.04,cutoff:800}]}}},{id:"matrix-rain",version:"1.0.0",sdkVersion:"1.0",name:"Matrix Rain",description:"Watch fictional digital characters drift in restrained green columns.",category:"Environment",tags:["matrix","original","playful"],scope:"viewport",interaction:"automatic",intensity:"low",icon:"M6 6h20v20h-20z",color:"#69af93",source:{researchId:"candidate-matrix-rain",name:"CriminalPear Bookmarklet Collection: MatrixRain",author:"criminalpear (collection)",url:"https://github.com/criminalpear/Bookmarklets",relationship:"Independent implementation of described concept; no source or assets reused",license:"Project-owned original code, icons and synthesized audio; historical source license unverified"},enabled:!0,status:"review-pending",activation:"replace",capabilities:{reducedMotion:!0,audio:!0,pause:!1},lifetime:{class:"continuous",overlap:"replace",animationMs:1000,residueMs:0},iconSvg:`<svg viewBox="0 0 32 32" xmlns="http://www.w3.org/2000/svg"><defs><linearGradient id="ICON-g" x1="0" y1="0" x2=".7" y2="1"><stop stop-color="#b0efc1"/><stop offset="1" stop-color="#63b894"/></linearGradient></defs><g stroke="#344559" stroke-width=".7" stroke-linecap="round" stroke-linejoin="round"><rect x="4" y="2" width="24" height="28" rx="6" fill="#284b40"/><g fill="none" stroke="url(#ICON-g)" stroke-width="2"><path d="M9 6v5m-2-3 2-2 2 2M16 4v4m-2 3h4l-4 4h4M23 8v5m-2 3 2 2 2-2M9 16v4m-2 3h4M16 21v5m5-2h4"/></g></g></svg>
`,audioProfile:{activate:{layers:[{wave:"triangle",frequency:360,endFrequency:180,duration:0.21,gain:0.035},{wave:"sine",frequency:720,endFrequency:540,duration:0.13,gain:0.025,delay:0.06}]}}},{id:"page-dance",version:"1.0.0",sdkVersion:"1.0",name:"Page Dance",description:"Make visible content dance in a coordinated rhythm.",category:"Play",tags:["page","playful"],scope:"document",interaction:"automatic",intensity:"medium",icon:"M4 5h24v23H4z",color:"#a78bfa",source:{researchId:"cr004-page-dance",name:"Harlem Shake bookmarklet",author:"Moovweb; Hari Ananth, Omar Jalalzada, Ishan Anand",url:"https://hacks.mozilla.org/2014/02/html5-css3-and-the-bookmarklet-that-shook-the-web/",relationship:"Independently reconstructed behavioral inspiration; no source or assets reused",license:"Project-owned implementation, icon and procedural audio; original source license not relied upon"},enabled:!0,status:"review-pending",activation:"replace",capabilities:{reducedMotion:!0,audio:!0,pause:!1},lifetime:{overlap:"replace",animationMs:1200,residueMs:0,class:"simulation"},iconSvg:`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32"><defs><linearGradient id="ICON-g" x1="0" y1="0" x2="1" y2="1"><stop stop-color="#d7b5fc"/><stop offset="1" stop-color="#9175df"/></linearGradient></defs><path d="M5 12h13v17H5z" fill="url(#ICON-g)" transform="rotate(-12 12 20)"/><path d="M8 15h7M8 19h6M8 23h5" stroke="#fff" stroke-width="1.5"/><path d="M22 4v15c-6-2-7 6-2 6 3 0 4-2 4-5V8l5-2V2z" fill="#f7ad55"/></svg>
`,audioProfile:{activate:{layers:[{wave:"sine",frequency:180,endFrequency:70,duration:0.12,gain:0.075},{wave:"triangle",frequency:330,duration:0.1,gain:0.035,delay:0.15},{wave:"sine",frequency:180,endFrequency:70,duration:0.12,gain:0.06,delay:0.3},{wave:"triangle",frequency:440,duration:0.12,gain:0.03,delay:0.45}]}}},{id:"punch-element",version:"1.2.0",sdkVersion:"1.0",name:"Punch",description:"Give that message a comic-book right hook.",category:"Impact",tags:["impact","fun"],scope:"element",interaction:"click",intensity:"medium",icon:"M8 20h9l4-8-3-3-3 2-2-7-3 1 1 8-4-3-2 2z",color:"#f1809a",source:{researchId:"candidate-punch-element",name:"Anger Relief Toy concept",author:"Project brief",url:"",relationship:"original",license:"Project-owned original implementation"},enabled:!0,status:"review-pending",activation:"replace",capabilities:{reducedMotion:!0,audio:!0,pause:!1},lifetime:{class:"repeatable",overlap:"replace",animationMs:1000,residueMs:200},iconSvg:`<svg viewBox="0 0 32 32" xmlns="http://www.w3.org/2000/svg"><defs><linearGradient id="ICON-g" x1="0" y1="0" x2=".7" y2="1"><stop stop-color="#ff867e"/><stop offset="1" stop-color="#cc304c"/></linearGradient></defs><g stroke="#344559" stroke-width=".7" stroke-linecap="round" stroke-linejoin="round"><path d="M9 22c-2-2-3-5-2-8-3-2-2-6 1-6 1-5 6-6 10-4 7 2 8 9 4 14l-4 6z" fill="url(#ICON-g)"/><path d="m8 21 10 3-2 6-10-3z" fill="#c82e49"/><path d="m8 24 8 2" stroke="#ffd5d2" stroke-width="2"/><path d="M10 8c2-3 6-3 9-1" stroke="#ffd5d2" stroke-width="1.5" fill="none"/><path d="M9 13c1 3 4 5 7 4" fill="none" stroke="#ad2940"/></g></svg>
`,audioProfile:{activate:{layers:[{wave:"noise",frequency:100,duration:0.035,gain:0.025,cutoff:750}]},impact:{layers:[{wave:"sine",frequency:145,duration:0.15,gain:0.15,endFrequency:48},{wave:"noise",frequency:100,duration:0.07,gain:0.1,cutoff:1450}]}}},{id:"rubber-band",version:"1.2.0",sdkVersion:"1.0",name:"Rubber",description:"Make a perfectly serious card wobble like jelly.",category:"Elastic",tags:["elastic","fun"],scope:"element",interaction:"click",intensity:"medium",icon:"M3 12c0-10 18-10 18 0s-18 10-18 0zM7 12c0-4 10-4 10 0s-10 4-10 0z",color:"#d9afdd",source:{researchId:"candidate-rubber-band",name:"Anger Relief Toy concept",author:"Project brief",url:"",relationship:"original",license:"Project-owned original implementation"},enabled:!0,status:"review-pending",activation:"replace",capabilities:{reducedMotion:!0,audio:!0,pause:!1},lifetime:{class:"repeatable",overlap:"replace",animationMs:1300,residueMs:200},iconSvg:`<svg viewBox="0 0 32 32" xmlns="http://www.w3.org/2000/svg"><defs><linearGradient id="ICON-g" x1="0" y1="0" x2=".7" y2="1"><stop stop-color="#ffb5cc"/><stop offset="1" stop-color="#d8558b"/></linearGradient></defs><g stroke="#344559" stroke-width=".7" stroke-linecap="round" stroke-linejoin="round"><ellipse cx="16" cy="22" rx="13" ry="7" fill="#b74074"/><path d="M3 13v9c0 9 26 9 26 0v-9" fill="url(#ICON-g)"/><ellipse cx="16" cy="13" rx="13" ry="7" fill="url(#ICON-g)"/><ellipse cx="16" cy="13" rx="8" ry="3.5" fill="#89365c"/><path d="M5 18c5 5 17 5 22 0M5 23c5 4 17 4 22 0" fill="none" stroke="#ffb7d0" stroke-width="1"/></g></svg>
`,audioProfile:{activate:{layers:[{wave:"triangle",frequency:170,duration:0.45,gain:0.07,endFrequency:530},{wave:"sine",frequency:400,duration:0.25,gain:0.045,endFrequency:140}]}}},{id:"screen-crack",version:"1.2.0",sdkVersion:"1.0",name:"Screen Crack",description:"Leave a spiderweb of cracks across the screen.",category:"Fracture",tags:["fracture","fun","break","smash","glass"],scope:"viewport",interaction:"automatic",intensity:"low",icon:"M12 12L3 2m9 10 9-9m-9 9 9 9m-9-9L2 21M12 12l-2-6 5 2 2 7-7 3z",color:"#abc5ec",source:{researchId:"candidate-screen-crack",name:"Anger Relief Toy concept",author:"Project brief",url:"",relationship:"original",license:"Project-owned original implementation"},enabled:!0,status:"review-pending",activation:"replace",capabilities:{reducedMotion:!0,audio:!0,pause:!1},lifetime:{class:"persistent",overlap:"replace",animationMs:1000,residueMs:200},iconSvg:`<svg viewBox="0 0 32 32" xmlns="http://www.w3.org/2000/svg"><defs><linearGradient id="ICON-g" x1="0" y1="0" x2=".7" y2="1"><stop stop-color="#9ce4fa"/><stop offset="1" stop-color="#4597bd"/></linearGradient></defs><g stroke="#344559" stroke-width=".7" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4" width="26" height="23" rx="3" fill="#526479"/><rect x="5" y="6" width="22" height="18" rx="1" fill="url(#ICON-g)"/><path d="m7 8 8 6 8-6m-8 6 10 7m-10-7-7 9m7-9 2 9m-2-9-2-6m2 6-9 2m9-2 7 1" stroke="#f2ffff" stroke-width=".9" fill="none"/><path d="M12 30h8" stroke="#526479" stroke-width="2"/></g></svg>
`,audioProfile:{activate:{layers:[{wave:"noise",frequency:800,duration:0.085,gain:0.08,cutoff:3400},{wave:"triangle",frequency:2300,duration:0.16,gain:0.025,endFrequency:1100}]}}},{id:"snowfall",version:"1.0.0",sdkVersion:"1.0",name:"Snowfall",description:"Let a quiet field of snow drift over the page until stopped.",category:"Environment",tags:["snowfall","original","playful"],scope:"viewport",interaction:"automatic",intensity:"low",icon:"M6 6h20v20h-20z",color:"#83b9d3",source:{researchId:"candidate-snowfall",name:"DevBubba collection: Let It Snow",author:"DevBubba (historical lead, unverified)",url:"https://devbubba.github.io/Bookmarklets/",relationship:"Independent implementation of described concept; no source or assets reused",license:"Project-owned original code, icons and synthesized audio; historical source license unverified"},enabled:!0,status:"review-pending",activation:"replace",capabilities:{reducedMotion:!0,audio:!0,pause:!1},lifetime:{class:"continuous",overlap:"replace",animationMs:1000,residueMs:0},iconSvg:`<svg viewBox="0 0 32 32" xmlns="http://www.w3.org/2000/svg"><defs><linearGradient id="ICON-g" x1="0" y1="0" x2=".7" y2="1"><stop stop-color="#b5e7f3"/><stop offset="1" stop-color="#76a9d5"/></linearGradient></defs><g stroke="#344559" stroke-width=".7" stroke-linecap="round" stroke-linejoin="round"><circle cx="16" cy="16" r="13" fill="url(#ICON-g)" stroke="none"/><g fill="none" stroke="#fff" stroke-width="1.8"><path d="M16 5v22M6.5 10.5l19 11M6.5 21.5l19-11M12 8l4 4 4-4M12 24l4-4 4 4M7 15l5-1-1-5M25 17l-5 1 1 5M7 17l5 1-1 5M25 15l-5-1 1-5"/></g></g></svg>
`,audioProfile:{activate:{layers:[{wave:"sine",frequency:620,endFrequency:860,duration:0.35,gain:0.025,attack:0.06}]}}},{id:"television-glitch",version:"1.0.0",sdkVersion:"1.0",name:"Television Glitch",description:"Slip a selected surface into gently displaced television scanlines.",category:"Transform",tags:["television","original","playful"],scope:"element",interaction:"click",intensity:"low",icon:"M6 6h20v20h-20z",color:"#ac8cdb",source:{researchId:"candidate-television-glitch",name:"DevBubba collection: Glitch",author:"DevBubba (historical lead, unverified)",url:"https://devbubba.github.io/Bookmarklets/",relationship:"Independent implementation of described concept; no source or assets reused",license:"Project-owned original code, icons and synthesized audio; historical source license unverified"},enabled:!0,status:"review-pending",activation:"replace",capabilities:{reducedMotion:!0,audio:!0,pause:!1},lifetime:{class:"repeatable",overlap:"replace",animationMs:1000,residueMs:300},iconSvg:`<svg viewBox="0 0 32 32" xmlns="http://www.w3.org/2000/svg"><defs><linearGradient id="ICON-g" x1="0" y1="0" x2=".7" y2="1"><stop stop-color="#94d5db"/><stop offset="1" stop-color="#bc8bd3"/></linearGradient></defs><g stroke="#344559" stroke-width=".7" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="6" width="26" height="20" rx="5" fill="#5b536b"/><rect x="6" y="9" width="20" height="13" rx="2" fill="url(#ICON-g)"/><path d="M7 13h7l2-2h8M8 18h5l2 2h9" fill="none" stroke="#f8cedf" stroke-width="2"/><path d="m11 3 5 3 6-4M12 29h8" fill="none"/></g></svg>
`,audioProfile:{activate:{layers:[{wave:"noise",frequency:150,duration:0.14,gain:0.045,cutoff:1500},{wave:"triangle",frequency:95,endFrequency:70,duration:0.12,gain:0.035}]}}},{id:"text-bomb",version:"1.2.0",sdkVersion:"1.0",name:"Text Bomb",description:"Plant a tiny bomb. Send the words flying.",category:"Destruction",tags:["destruction","fun"],scope:"element",interaction:"click",intensity:"medium",icon:"M16 7l2-3 3 1M14 4l2 3M18 15a7 7 0 1 1-7-7h3z",color:"#f3bc68",source:{researchId:"candidate-text-bomb",name:"fontBomb",author:"Philippe-Antoine Lehoux",url:"https://github.com/plehoux/fontBomb",relationship:"inspired-by",license:"No source or assets reused; original license unverified"},enabled:!0,status:"review-pending",activation:"replace",capabilities:{reducedMotion:!0,audio:!0,pause:!1},lifetime:{class:"repeatable",overlap:"replace",animationMs:2600,residueMs:200},iconSvg:`<svg viewBox="0 0 32 32" xmlns="http://www.w3.org/2000/svg"><defs><linearGradient id="ICON-g" x1="0" y1="0" x2=".7" y2="1"><stop stop-color="#7f8b9e"/><stop offset="1" stop-color="#283044"/></linearGradient></defs><g stroke="#344559" stroke-width=".7" stroke-linecap="round" stroke-linejoin="round"><path d="M20 9c1-7 5-6 7-3" fill="none" stroke="#b77d3a" stroke-width="2"/><path d="m28 2-1 3 4 1m-5 1 2 3" fill="none" stroke="#ffb53d" stroke-width="1.5"/><path d="m16 8 7 2-1 4-7-2z" fill="#42516a"/><circle cx="15" cy="21" r="10" fill="url(#ICON-g)"/><ellipse cx="12" cy="16" rx="4" ry="2.5" transform="rotate(-30 12 16)" fill="#eaf2ff" opacity=".6" stroke="none"/></g></svg>
`,audioProfile:{activate:{layers:[{wave:"sine",frequency:310,duration:0.075,gain:0.035,endFrequency:180}]},detonate:{layers:[{wave:"sine",frequency:125,duration:0.3,gain:0.13,endFrequency:38},{wave:"noise",frequency:150,duration:0.23,gain:0.09,cutoff:1500},{wave:"noise",frequency:1600,duration:0.13,gain:0.025,delay:0.1,cutoff:2900}]}}},{id:"vortex",version:"1.2.0",sdkVersion:"1.0",name:"Vortex",description:"Fold a piece of the internet into a tiny black hole.",category:"Surreal",tags:["surreal","fun"],scope:"element",interaction:"click",intensity:"medium",icon:"M21 12a9 9 0 1 1-9-9c8 0 9 13 1 13-6 0-6-8-1-8 4 0 4 5 1 5",color:"#9da7ef",source:{researchId:"candidate-vortex",name:"Anger Relief Toy concept",author:"Project brief",url:"",relationship:"original",license:"Project-owned original implementation"},enabled:!0,status:"review-pending",activation:"replace",capabilities:{reducedMotion:!0,audio:!0,pause:!1},lifetime:{class:"repeatable",overlap:"replace",animationMs:1800,residueMs:200},iconSvg:`<svg viewBox="0 0 32 32" xmlns="http://www.w3.org/2000/svg"><defs><linearGradient id="ICON-g" x1="0" y1="0" x2=".7" y2="1"><stop stop-color="#c5b1ff"/><stop offset="1" stop-color="#7550ca"/></linearGradient></defs><g stroke="#344559" stroke-width=".7" stroke-linecap="round" stroke-linejoin="round"><circle cx="16" cy="16" r="13" fill="#eee6ff" stroke="none"/><path d="M28 13C25 1 5 0 3 15c-2 16 20 20 25 5C32 8 14 3 9 12c-6 10 9 15 13 7 3-6-6-10-8-5-1 3 4 5 5 2" fill="none" stroke="url(#ICON-g)" stroke-width="3.5"/><circle cx="17" cy="16" r="3" fill="#584181" stroke="none"/></g></svg>
`,audioProfile:{activate:{layers:[{wave:"noise",frequency:300,duration:1,gain:0.055,cutoff:650,attack:0.2},{wave:"sine",frequency:110,duration:0.8,gain:0.028,endFrequency:240,attack:0.15}]}}},{id:"wrecking-ball",version:"1.0.0",sdkVersion:"1.0",name:"Wrecking Ball",description:"Swing a steel pendulum into a selected surface.",category:"Impact",tags:["wrecking","playful"],scope:"element",interaction:"click",intensity:"medium",icon:"M4 5h24v23H4z",color:"#94a3b8",source:{researchId:"cr004-wrecking-ball",name:"Web Pranks",author:"steveja42",url:"https://github.com/steveja42/webpranks",relationship:"Independently reconstructed behavioral inspiration; no source or assets reused",license:"Project-owned implementation, icon and procedural audio; original source license not relied upon"},enabled:!0,status:"review-pending",activation:"replace",capabilities:{reducedMotion:!0,audio:!0,pause:!1},lifetime:{overlap:"replace",animationMs:1800,residueMs:0,class:"repeatable"},iconSvg:`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32"><defs><linearGradient id="ICON-g" x1="0" y1="0" x2="1" y2="1"><stop stop-color="#c7d3e5"/><stop offset="1" stop-color="#45556e"/></linearGradient></defs><path d="M22 2 12 14" stroke="#76849b" stroke-width="3"/><circle cx="12" cy="21" r="10" fill="url(#ICON-g)"/><path d="m7 17 4-3" stroke="#f2f6ff" stroke-width="2" stroke-linecap="round"/></svg>
`,audioProfile:{activate:{layers:[{wave:"noise",frequency:350,cutoff:800,duration:0.18,gain:0.03}]},impact:{layers:[{wave:"sine",frequency:110,endFrequency:42,duration:0.35,gain:0.13},{wave:"noise",frequency:700,cutoff:1300,duration:0.17,gain:0.07}]}}}];class N{fail;cleanups=new Set;closed=!1;constructor(e=()=>{}){this.fail=e}get size(){return this.cleanups.size}own(e){if(this.closed)return e(),()=>{};return this.cleanups.add(e),()=>{this.cleanups.delete(e)}}node(e){return this.own(()=>e.parentNode?.removeChild(e)),e}listen(e,t,o,i={}){e.addEventListener(t,o,i),this.own(()=>e.removeEventListener(t,o,i))}timeout(e,t){if(this.closed)return;let o=setTimeout(()=>{if(i(),!this.closed)try{e()}catch{this.fail()}},t),i=this.own(()=>clearTimeout(o))}animate(e,t,o){let i=e.animate(t,o);return this.own(()=>i.cancel()),i.finished.catch(()=>{}),i}frame(e){if(this.closed)return;let t=0,o,i=0,n=this.own(()=>cancelAnimationFrame(t)),s=(r)=>{if(this.closed)return;o??=r;let c=!1;try{c=e(r-o,Math.min(32,r-(i||r)))}catch{this.fail()}if(i=r,c&&!this.closed)t=requestAnimationFrame(s);else n()};t=requestAnimationFrame(s)}style(e,t,o){let i=e.style.getPropertyValue(t),n=e.style.getPropertyPriority(t),s=e.hasAttribute("style");e.style.setProperty(t,o,"important"),this.own(()=>{if(e.style.getPropertyValue(t)!==o||e.style.getPropertyPriority(t)!=="important")return;if(i)e.style.setProperty(t,i,n);else e.style.removeProperty(t);if(!s&&!e.getAttribute("style"))e.removeAttribute("style")})}dispose(){if(this.closed)return;this.closed=!0;for(let e of[...this.cleanups].reverse())try{e()}catch{this.fail()}this.cleanups.clear()}}var ie={strength:0.65,duration:3,reducedMotion:!1,radius:160,darkness:0.86,softness:40};function _(e){let t=typeof e==="object"&&e!==null?e:{},o=(i,n,s)=>{let r=Object.hasOwn(t,i)?t[i]:void 0;return typeof r==="number"&&Number.isFinite(r)?Math.min(s,Math.max(n,r)):ie[i]};return{strength:o("strength",0.2,1),duration:o("duration",1,10),radius:o("radius",60,320),darkness:o("darkness",0.3,0.95),softness:o("softness",0,100),reducedMotion:Object.hasOwn(t,"reducedMotion")&&t.reducedMotion===!0}}function j(e){return e!==null&&typeof e==="object"&&!Array.isArray(e)}function le(e,t){Object.assign(e.style,{position:"fixed",left:`${t.left}px`,top:`${t.top}px`,width:`${t.width}px`,height:`${t.height}px`,margin:"0",pointerEvents:"none"})}var ye="input,textarea,select,[contenteditable]:not([contenteditable=false]),iframe,video,audio,canvas,script,style,noscript,[data-art-root]";function oe(e){let t=e;for(let o=0;t&&o<64;o++){if(t.matches(ye))return!0;t=t.parentElement??(t.getRootNode()instanceof ShadowRoot?t.getRootNode().host:null)}return!1}function a(e,t="",o=""){let i=document.createElement(e);return i.className=t,i.textContent=o,i}function E(e,t,o=""){let i=a("button",o,e);return i.type="button",i.onclick=t,i}var xe=0;function G(e,t=32){if(e.iconSvg)return e.iconSvg.replace("viewBox=",`width="${t}" height="${t}" aria-hidden="true" focusable="false" viewBox=`).replaceAll("ICON",`art-icon-${++xe}`);return`<svg width="${t}" height="${t}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" aria-hidden="true"><path d="${e.icon}"/></svg>`}function Z(e,t){let o=E("",t,"close-control");return o.setAttribute("aria-label",e),o.title=e,o.innerHTML='<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" aria-hidden="true"><path d="m6 6 12 12M18 6 6 18"/></svg>',o}function ue(e,t,o){let i=[...e.querySelectorAll('button,input,select,summary,a[href],[tabindex="0"]')].filter((c)=>!c.hasAttribute("disabled")&&c.getClientRects().length);if(t.key!=="Tab"||!i.length)return;let n=i.indexOf(o),s=t.shiftKey?-1:1,r=n<0?t.shiftKey?i.length-1:0:(n+s+i.length)%i.length;t.preventDefault(),t.stopPropagation(),i[r]?.focus()}async function U(){let e={};try{e=await chrome.storage.local.get("preferences")}catch{}let t=j(e.preferences)?e.preferences:{},o=(n)=>Array.isArray(n)?n.filter((s)=>typeof s==="string"&&I.some((r)=>r.id===s)).slice(0,32):[],i=j(t.audio)?t.audio:{};return{audio:{muted:i.muted===!0,volume:typeof i.volume==="number"&&Number.isFinite(i.volume)?Math.max(0,Math.min(1,i.volume)):0.2,effects:i.effects!==!1,navigation:i.navigation!==!1},middleHold:t.middleHold===!0,favorites:Array.isArray(t.favorites)?o(t.favorites):I.slice(0,4).map((n)=>n.id),recent:o(t.recent),options:_(t.options)}}async function ne(e,t,o){let i=await U(),n="All tools",s="",r="All categories";e.replaceChildren(),e.className="art-app";let c=a("header","brand");if(c.append(a("strong","","Anger Relief Toy")),o.close)c.append(Z("Close tools",o.close));e.append(c,a("h1","catalog-title","Choose a tool"));let d=a("div","shortcut-bar"),h=E("Open action wheel",()=>o.wheel?.(),"shortcut-action"),l=a("kbd","shortcut-binding");d.append(h,l),e.append(d);try{let b=await chrome.runtime.sendMessage({type:"shortcut"});l.textContent=j(b)&&typeof b.shortcut==="string"&&b.shortcut?b.shortcut:"Not assigned"}catch{l.textContent="Unavailable"}if(l.textContent==="Not assigned"||l.textContent==="Unavailable")d.append(a("p","shortcut-help","Assign Open action wheel in your browser's Extensions > Keyboard shortcuts."));let x=a("div","toolbar"),y=a("input","search");y.type="search",y.placeholder="Search tools",y.setAttribute("aria-label","Search effects"),y.oninput=()=>{s=y.value,D()};let C=a("select");C.setAttribute("aria-label","Filter by category");for(let b of["All categories",...new Set(I.map((u)=>u.category))]){let u=a("option","",b);C.append(u)}C.onchange=()=>{r=C.value,D()},x.append(y,C),e.append(x);let T=a("details","settings quick-settings");T.append(a("summary","","Sound and mouse shortcut"));let w=a("div","settings-grid");for(let[b,u]of[["Mute all sounds","muted"],["Effect sounds","effects"],["Dial sounds","navigation"]]){let A=a("label","motion"),H=a("input");H.type="checkbox",H.checked=i.audio[u],H.onchange=()=>{i.audio[u]=H.checked,F()},A.append(H,document.createTextNode(b)),w.append(A)}let k=a("label"),O=a("span","",`Volume: ${Math.round(i.audio.volume*100)}%`),P=a("input");P.type="range",P.min="0",P.max="100",P.value=String(i.audio.volume*100),P.oninput=()=>{i.audio.volume=Number(P.value)/100,O.textContent=`Volume: ${P.value}%`,F()},k.append(O,P),w.append(k);let S=a("label","motion"),L=a("input");L.type="checkbox",L.checked=i.middleHold,L.onchange=()=>{i.middleHold=L.checked,F()},S.append(L,document.createTextNode("Middle mouse hold opens dial")),w.append(S),w.append(a("p","help","Hold for 1.8 seconds on noninteractive page areas after activating the extension in this tab. Replaces middle-button autoscroll or paste on those areas while enabled. Links, fields and controls keep their normal behavior.")),T.append(w),e.append(T);let f=a("nav","tabs");f.setAttribute("aria-label","Tool collection");for(let b of["All tools","Favorites","Recent"]){let u=E(b,()=>{n=b,D()});u.dataset.mode=b,f.append(u)}e.append(f);let R=a("div","tool-grid");e.append(R);let B=a("p","status");B.setAttribute("role","status"),e.append(B);async function F(){try{await chrome.storage.local.set({preferences:i}),o.changed?.(),chrome.runtime.sendMessage({type:"preferences-changed"}).catch(()=>{})}catch{B.textContent="Could not save preferences. Try again after freeing extension storage."}}function D(){for(let u of f.querySelectorAll("button"))u.setAttribute("aria-pressed",String(u.dataset.mode===n));R.replaceChildren();let b=I.filter((u)=>(n!=="Favorites"||i.favorites.includes(u.id))&&(n!=="Recent"||i.recent.includes(u.id))&&(r==="All categories"||u.category===r)&&`${u.name} ${u.description} ${u.tags.join(" ")}`.toLowerCase().includes(s.toLowerCase()));if(n==="Recent")b=b.sort((u,A)=>i.recent.indexOf(u.id)-i.recent.indexOf(A.id));if(!b.length)R.append(a("p","empty",n==="Favorites"?"Star a tool to keep it close.":n==="Recent"?"Your recently used tools will appear here.":"No tools match. Try 'glass', 'light' or 'physics'."));for(let u of b){let A=a("article","tool");A.dataset.id=u.id,A.setAttribute("data-equipped",String(o.equipped?.()===u.id));let H=E("",()=>{(async()=>{B.textContent=`Preparing ${u.name}...`;try{await t(u.id,i.options),B.textContent=u.scope==="element"?`${u.name} ready. Choose something on the page.`:`${u.name} equipped. Put away ends the tool.`}catch{B.textContent="Open an ordinary webpage, then click the extension again. Browser settings and store pages are protected."}})()},"tool-use");H.setAttribute("aria-label",`Equip ${u.name}`),H.setAttribute("aria-pressed",String(o.equipped?.()===u.id));let X=a("div","tool-art");X.innerHTML=G(u,38),H.append(X,a("h2","",u.name),a("p","",u.description));let K=E(i.favorites.includes(u.id)?"★":"☆",()=>{if(i.favorites.includes(u.id))i.favorites=i.favorites.filter((Y)=>Y!==u.id);else i.favorites.push(u.id);F(),D()},"favorite");K.setAttribute("aria-label",`Favorite ${u.name}`),K.setAttribute("aria-pressed",String(i.favorites.includes(u.id))),A.append(H,K),R.append(A)}}let g=a("footer","footer"),p=E("Put away",o.stop,"put-away");p.disabled=!o.equipped?.(),g.append(p),e.append(g);let v=a("details","settings");v.append(a("summary","","Tool settings"));let m=a("div","settings-grid");for(let[b,u,A,H,X]of[["Strength","strength",0.2,1,0.1],["One-shot restore after (seconds)","duration",1,10,1],["Flashlight radius","radius",60,320,10],["Flashlight darkness","darkness",0.3,0.95,0.05],["Flashlight softness","softness",0,100,5]]){let K=a("label"),Y=a("span","",`${b}: ${i.options[u]}`),V=a("input");V.type="range",V.min=String(A),V.max=String(H),V.step=String(X),V.value=String(i.options[u]),V.oninput=()=>{i.options[u]=Number(V.value),Y.textContent=`${b}: ${V.value}`,F()},K.append(Y,V),m.append(K)}let M=a("label","motion"),q=a("input");q.type="checkbox",q.checked=i.options.reducedMotion,q.onchange=()=>{i.options.reducedMotion=q.checked,F()},M.append(q,document.createTextNode("Reduce motion (system preference also applies)")),m.append(M),v.append(m),v.append(a("p","help","Equip a tool, then click elements repeatedly. Document and viewport tools start when equipped; reselect to restart after End effect. Escape closes the open menu, otherwise puts the tool away. Form fields and embedded content are protected.")),v.append(E("Reset preferences",()=>{i.options={...ie},i.audio={muted:!1,volume:0.2,effects:!0,navigation:!0},i.middleHold=!1,i.favorites=I.slice(0,4).map((b)=>b.id),i.recent=[],F().then(()=>ne(e,t,o))},"quiet"));let ee=a("details");ee.append(a("summary","","Credits and sources"));for(let b of I){let u=a("p","credit");if(u.append(a("strong","",`${b.name}: `),document.createTextNode(`${b.source.name}, ${b.source.author}. ${b.source.relationship}. ${b.source.license}. `)),b.source.url){let A=a("a","","Source");A.href=b.source.url,A.target="_blank",A.rel="noopener noreferrer",u.append(A)}ee.append(u)}e.append(ee);let W=a("details");W.append(a("summary","","Local diagnostics"));let te=a("pre","diagnostics");W.append(E("Clear diagnostics",()=>{o.clearDiagnostics(),te.textContent="Diagnostics cleared."},"quiet")),W.append(E("View sanitized report",()=>{o.diagnostics().then((b)=>{te.textContent=JSON.stringify(b,null,2)})},"quiet"),te),e.append(W),e.append(v),D()}function ke(e,t,o,i={width:innerWidth,height:innerHeight}){return{x:Math.max(8,Math.min(Math.max(8,i.width-t-8),e.x)),y:Math.max(8,Math.min(Math.max(8,i.height-Math.min(o,96)-8),e.y))}}function pe(e,t,o=48,i={width:innerWidth,height:innerHeight}){return{x:Math.max(8,Math.min(i.width-o-8,e+38)),y:Math.max(8,Math.min(i.height-o-8,t+38))}}function he(e,t,o,i,n){let s=i,r,c=(h)=>{let l=e.getBoundingClientRect();s=ke(h,l.width,l.height),e.style.left=`${s.x}px`,e.style.top=`${s.y}px`,e.style.transform="none",n(s)};if(s)c(s);let d=()=>{let h=r;if(r=void 0,h&&t.hasPointerCapture?.(h.id))t.releasePointerCapture(h.id);e.removeAttribute("data-dragging")};o.listen(t,"pointerdown",(h)=>{let l=h;if(l.button!==0||l.target.closest("button,input,select,a,summary"))return;let x=e.getBoundingClientRect();r={id:l.pointerId,startX:l.clientX,startY:l.clientY,origin:{x:x.left,y:x.top}},t.setPointerCapture?.(l.pointerId),e.dataset.dragging="",l.preventDefault(),l.stopPropagation()}),o.listen(t,"pointermove",(h)=>{let l=h;if(!r||r.id!==l.pointerId)return;c({x:r.origin.x+l.clientX-r.startX,y:r.origin.y+l.clientY-r.startY}),l.preventDefault(),l.stopPropagation()});for(let h of["pointerup","pointercancel","lostpointercapture"])o.listen(t,h,d);o.listen(window,"blur",d),o.listen(window,"resize",()=>{if(d(),s)c(s)}),o.own(d),t.tabIndex=0,t.title="Drag to move. Arrow keys move when focused.",t.setAttribute("aria-label","Move tools window"),o.listen(t,"keydown",(h)=>{let l=h;if(l.target!==t||!l.key.startsWith("Arrow"))return;let x=e.getBoundingClientRect();c({x:x.left+(l.key==="ArrowLeft"?-24:l.key==="ArrowRight"?24:0),y:x.top+(l.key==="ArrowUp"?-24:l.key==="ArrowDown"?24:0)}),l.preventDefault(),l.stopPropagation()})}var fe={tick:{layers:[{wave:"noise",frequency:600,duration:0.016,gain:0.025,cutoff:1700},{wave:"triangle",frequency:900,endFrequency:550,duration:0.025,gain:0.012}]},select:{layers:[{wave:"triangle",frequency:500,endFrequency:760,duration:0.065,gain:0.035}]}};var J=(e,t)=>(e%t+t)%t;class se{count;slots;step;position=0;constructor(e){this.count=e;if(!Number.isInteger(e)||e<1)throw Error("EMPTY_DIAL");this.slots=Math.min(9,e+1),this.step=360/this.slots}set(e){if(!Number.isFinite(e))return;let t=this.slots*this.count;this.position=J(e+t/2,t)-t/2}slot(e){let t=e+this.position,o=J(t,this.slots),i=Math.min(o,this.slots-o)*this.step;return{index:J(this.slots-1-e+Math.floor(t/this.slots)*this.slots,this.count),angle:-135+o*this.step,covered:i<24}}get topIndex(){return J(Math.round(this.position)+this.slots-2,this.count)}}function Me(e,t,o=-90){let i=(o+e*360/t)*Math.PI/180,n=Math.PI/t-0.012,s=[];for(let r=0;r<=12;r++){let c=i-n+2*n*r/12;s.push(`${50+Math.cos(c)*49}% ${50+Math.sin(c)*49}%`)}for(let r=12;r>=0;r--){let c=i-n+2*n*r/12;s.push(`${50+Math.cos(c)*19}% ${50+Math.sin(c)*19}%`)}return`polygon(${s.join(",")})`}function me(e,t,o,i,n,s,r=new N,c){let d=new se(e.length),h=Math.max(0,e.findIndex((g)=>g.id===t));d.set(h-(d.slots-2));let l=a("section","wheel-dialog");l.setAttribute("role","dialog"),l.setAttribute("aria-modal","true"),l.setAttribute("aria-label","Action dial");let x=a("div","wheel-heading");x.append(a("span","shortcut",o||"Assign a shortcut in extension settings"),Z("Close dial",s));let y=a("div","wheel");y.setAttribute("aria-label","Rotate to browse tools");let C=a("div","dial-mask"),T=a("div","dial-rotor");C.append(T);let w=[];for(let g=0;g<d.slots;g++){let p=E("",()=>{if(d.slot(g).covered)return;c?.play("select"),i(e[d.slot(g).index].id)},"wheel-sector");p.style.clipPath=Me(g,d.slots,-135);let v=a("span","sector-content"),m=(-135+g*d.step)*Math.PI/180;v.style.left=`${50+Math.cos(m)*34}%`,v.style.top=`${50+Math.sin(m)*34}%`,p.append(v),T.append(p),w.push({button:p,content:v,index:-1})}let k=a("div","dial-separator");k.innerHTML='<svg viewBox="0 0 420 420" aria-hidden="true"><defs><linearGradient id="art-arm" x2=".8" y2="1"><stop stop-color="#fff"/><stop offset=".35" stop-color="#eef2f2"/><stop offset=".7" stop-color="#b8c4ca"/><stop offset="1" stop-color="#e9edf0"/></linearGradient></defs><path d="M9 131 A224 224 0 0 1 131 9 L181 136 A79 79 0 0 0 136 181 Z" fill="#637481" opacity=".3" transform="translate(3 5)"/><path d="M9 131 A224 224 0 0 1 131 9 L181 136 A79 79 0 0 0 136 181 Z" fill="url(#art-arm)" stroke="#9cabb5"/><path d="M15 127 A218 218 0 0 1 127 15" fill="none" stroke="white" stroke-width="3"/><path d="M35 -2 Q28 -9 21 -2 L-2 21 Q-9 28 -2 35 L88 121 L121 88 Z" fill="url(#art-arm)" stroke="#a1b0b8"/><path d="M0 26 L96 117" fill="none" stroke="white" stroke-width="2"/><circle cx="24" cy="24" r="8" fill="#edf2f4" stroke="#a1b0b8"/><path d="M20 24h8" stroke="#879ba7"/><circle cx="58" cy="58" r="15" fill="#e5eaed" stroke="#95a6af"/><path d="M52 58h12" stroke="#8497a2" stroke-width="2"/><path d="M135 178 A82 82 0 0 1 178 135" fill="none" stroke="#71858f" stroke-width="3"/></svg>';let O=E("All tools",n,"wheel-center");y.append(C,k,O),l.append(x,y,a("p","wheel-help","Drag the rim to browse. Arrow keys rotate. Esc closes."));let P=Math.round(d.position),S,L=!1,f;function R(g=!0){T.style.transform=`rotate(${d.position*d.step}deg)`;for(let v=0;v<w.length;v++){let m=w[v],M=d.slot(v),q=e[M.index];if(m.index!==M.index){if(m.index=M.index,m.content.innerHTML=G(q,36),m.content.append(a("span","sector-name",q.name)),q.id===t)m.content.append(a("span","equipped-check","✓"));m.button.dataset.id=q.id,m.button.setAttribute("aria-label",`Equip ${q.name}`),m.button.setAttribute("aria-pressed",String(q.id===t))}m.button.disabled=M.covered,m.button.tabIndex=!M.covered&&M.index===d.topIndex?0:-1,m.content.style.transform=`translate(-50%, -50%) rotate(${-d.position*d.step}deg)`}let p=Math.round(d.position);if(g&&P!==p)c?.play("tick");P=p,y.dataset.position=String(d.position)}function B(g=Math.round(d.position),p=!1){S?.dispose(),S=new N;let v=d.position,m=()=>{if(d.set(g),R(),p)w.find((M)=>!M.button.disabled&&M.index===d.topIndex)?.button.focus()};if(p||matchMedia("(prefers-reduced-motion: reduce)").matches||Math.abs(g-v)<0.001){m();return}S.frame((M)=>{let q=Math.min(1,M/140);if(d.set(v+(g-v)*(1-(1-q)**3)),R(),q===1)return m(),!1;return!0})}let F=(g,p,v,m)=>{let M=Math.atan2(p-m,g-v)*180/Math.PI;return Math.abs((M+135+540)%360-180)<24};r.listen(y,"pointerdown",(g)=>{let p=g;if(p.button!==0||p.target.closest(".wheel-center"))return;let v=y.getBoundingClientRect(),m=v.left+v.width/2,M=v.top+v.height/2;if(Math.hypot(p.clientX-m,p.clientY-M)<v.width*0.2||F(p.clientX,p.clientY,m,M))return;S?.dispose(),L=!1,f={id:p.pointerId,x:p.clientX,y:p.clientY,cx:m,cy:M,previous:Math.atan2(p.clientY-M,p.clientX-m),started:!1}}),r.listen(window,"pointermove",(g)=>{let p=g;if(!f||p.pointerId!==f.id)return;if(!f.started&&Math.hypot(p.clientX-f.x,p.clientY-f.y)<6)return;if(!f.started)f.started=!0,y.setPointerCapture?.(p.pointerId);L=!0,p.preventDefault();let v=Math.atan2(p.clientY-f.cy,p.clientX-f.cx),m=v-f.previous;if(m>Math.PI)m-=Math.PI*2;if(m<-Math.PI)m+=Math.PI*2;d.set(d.position+m*180/Math.PI/d.step),f.previous=v,R()},{passive:!1});let D=(g)=>{if(!f||g&&"pointerId"in g&&g.pointerId!==f.id)return;let p=f.started,v=f.id;if(f=void 0,y.hasPointerCapture?.(v))y.releasePointerCapture(v);if(p)B()};return r.listen(window,"pointerup",D),r.listen(window,"pointercancel",D),r.listen(y,"lostpointercapture",D),r.listen(window,"resize",D),r.listen(window,"blur",D),r.listen(y,"click",(g)=>{if(L&&g.detail>0)g.preventDefault(),g.stopImmediatePropagation()},{capture:!0}),r.listen(y,"keydown",(g)=>{let p=g;if(!["ArrowLeft","ArrowUp","ArrowRight","ArrowDown"].includes(p.key))return;p.preventDefault(),p.stopPropagation(),B(Math.round(d.position)+(["ArrowLeft","ArrowUp"].includes(p.key)?-1:1),!0)}),r.own(()=>{if(S?.dispose(),f&&y.hasPointerCapture?.(f.id))y.releasePointerCapture(f.id);f=void 0,c?.stop()}),R(!1),l}var ge=`:host {
  all: initial;
  font:
    14px/1.45 system-ui,
    -apple-system,
    "Segoe UI",
    sans-serif;
  color: #26323c;
  --ink: #26323c;
  --muted: #58656f;
  --glass: rgba(250, 252, 254, 0.9);
  --line: rgba(72, 91, 106, 0.2);
  --accent: #daf4f6;
  --focus: #167d97;
  --shadow: 0 10px 40px rgba(25, 45, 62, 0.14), inset 0 1px 0 #fff;
}
* {
  box-sizing: border-box;
}
[hidden] {
  display: none !important;
}
button,
input,
select {
  font: inherit;
  color: inherit;
}
button {
  cursor: pointer;
  border: 0;
  background: transparent;
  touch-action: manipulation;
}
button:focus-visible,
input:focus-visible,
select:focus-visible,
summary:focus-visible,
[tabindex]:focus-visible {
  outline: 3px solid var(--focus, #167d97);
  outline-offset: 3px;
}
button:disabled {
  opacity: 0.5;
  cursor: wait;
}
svg {
  display: block;
  flex-shrink: 0;
}
h1,
h2,
p {
  margin: 0;
}
a {
  color: #176782;
}
button:hover {
  background-color: #eaf5f7;
}
button:active {
  background-color: #d6eef1;
}
.art-app {
  --ink: #26323c;
  --muted: #58656f;
  --glass: rgba(250, 252, 254, 0.9);
  --line: rgba(72, 91, 106, 0.2);
  --focus: #167d97;
  color: var(--ink);
  font:
    14px/1.45 system-ui,
    -apple-system,
    "Segoe UI",
    sans-serif;
  padding: 20px;
  text-align: left;
  min-width: 0;
}
.brand {
  display: flex;
  align-items: center;
  gap: 12px;
  min-height: 40px;
  margin-bottom: 14px;
}
.brand strong {
  font-size: 16px;
  font-weight: 600;
}
.brand .close-control {
  margin-left: auto;
}
.close-control {
  display: grid;
  place-items: center;
  width: 38px;
  height: 38px;
  border: 1px solid var(--line);
  border-radius: 50%;
  background: rgba(255, 255, 255, 0.65);
  flex-shrink: 0;
}
.catalog-title {
  font-size: 26px;
  font-weight: 650;
  letter-spacing: -0.5px;
  margin-bottom: 14px;
}
.shortcut-bar {
  display: flex;
  align-items: center;
  flex-wrap: wrap;
  gap: 8px;
  margin-bottom: 18px;
}
.shortcut-action {
  padding: 0;
  text-decoration: underline;
  text-underline-offset: 3px;
  font-weight: 500;
}
.shortcut-binding {
  padding: 4px 7px;
  border: 1px solid var(--line);
  border-radius: 7px;
  font:
    14px system-ui,
    sans-serif;
  background: #fff8;
}
.shortcut-help {
  flex-basis: 100%;
  color: var(--muted);
}
.toolbar {
  display: flex;
  gap: 8px;
}
.search {
  min-width: 0;
  width: 100%;
  border: 1px solid var(--line);
  background: #ffffffb8;
  border-radius: 10px;
  padding: 10px 12px;
}
.toolbar select {
  min-width: 0;
  max-width: 150px;
  border: 1px solid var(--line);
  border-radius: 10px;
  background: #fff9;
  padding: 8px;
}
.tabs {
  display: flex;
  gap: 20px;
  margin: 18px 0 14px;
  border-bottom: 1px solid var(--line);
}
.tabs button {
  padding: 0 0 9px;
  border-bottom: 2px solid transparent;
}
.tabs button[aria-pressed="true"] {
  border-color: #167d97;
  font-weight: 600;
}
.tool-grid {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 10px;
}
.tool {
  position: relative;
  border: 1px solid var(--line);
  border-radius: 13px;
  background: #ffffff70;
  overflow: hidden;
}
.tool:hover {
  background: #fff;
  border-color: #7f9fac;
}
.tool[data-equipped="true"] {
  border-color: #3b919f;
  background: #e9f8fa;
}
.tool-use {
  display: block;
  width: 100%;
  text-align: left;
  padding: 14px;
}
.tool-art {
  height: 46px;
  display: flex;
  align-items: center;
  margin-bottom: 7px;
}
.tool-art svg {
  filter: drop-shadow(0 1px 1px #23334018);
}
.tool h2 {
  font-size: 16px;
  font-weight: 600;
  margin: 0 24px 4px 0;
}
.tool p {
  font-size: 14px;
  color: var(--muted);
  line-height: 1.4;
  min-height: 40px;
}
.favorite {
  position: absolute;
  right: 6px;
  top: 7px;
  width: 36px;
  height: 36px;
  font-size: 23px;
  line-height: 1;
  border-radius: 9px;
  color: #647686;
}
.favorite[aria-pressed="true"] {
  color: #8d6517;
}
.status {
  font-size: 14px;
  margin-top: 12px;
  color: #286a77;
}
.status:empty {
  display: none;
}
.footer {
  display: flex;
  justify-content: flex-end;
  padding-top: 14px;
}
.put-away {
  border: 1px solid var(--line);
  border-radius: 10px;
  padding: 9px 12px;
  background: #ffffff80;
}
.settings,
.art-app > details {
  border-top: 1px solid var(--line);
  margin-top: 16px;
  padding-top: 12px;
}
summary {
  cursor: pointer;
  padding: 5px 0;
  font-size: 14px;
}
.settings-grid {
  display: grid;
  gap: 12px;
  margin: 12px 0;
}
.settings label {
  display: grid;
  gap: 6px;
}
.settings input[type="range"] {
  width: 100%;
  accent-color: #39859b;
}
.settings .motion {
  display: flex;
  align-items: center;
}
.help,
.credit {
  font-size: 14px;
  line-height: 1.55;
  margin: 12px 0;
  color: var(--muted);
}
.quiet {
  padding: 8px;
  text-decoration: underline;
  text-underline-offset: 3px;
}
.diagnostics {
  font-size: 13px;
  max-height: 250px;
  overflow: auto;
  white-space: pre-wrap;
}
.empty {
  grid-column: 1/-1;
  padding: 24px 8px;
  color: var(--muted);
}
.menu-scrim {
  position: fixed;
  inset: 0;
  background: rgba(28, 44, 58, 0.035);
  pointer-events: auto;
  z-index: 40;
}
.menu-layer {
  position: fixed;
  inset: 0;
  pointer-events: none;
  z-index: 41;
}
.art-dialog {
  position: fixed;
  left: 50%;
  top: 50%;
  transform: translate(-50%, -50%);
  width: min(700px, calc(100vw - 32px));
  max-height: calc(100vh - 40px);
  overflow: auto;
  border: 1px solid #ffffffb8;
  border-radius: 21px;
  background: var(--glass);
  backdrop-filter: blur(24px) saturate(1.1);
  box-shadow: var(--shadow);
  pointer-events: auto;
  overscroll-behavior: contain;
}
.art-dialog .brand {
  cursor: grab;
  touch-action: none;
  user-select: none;
}
.art-dialog[data-dragging] .brand {
  cursor: grabbing;
}
.art-dialog .brand button {
  cursor: pointer;
}
.art-dialog .tool-grid {
  grid-template-columns: repeat(3, minmax(0, 1fr));
}
.wheel-dialog {
  position: fixed;
  left: 50%;
  top: 50%;
  transform: translate(-50%, -50%);
  pointer-events: auto;
  --wheel-size: min(420px, calc(100vw - 32px), calc(100vh - 156px));
  width: var(--wheel-size);
  color: var(--ink);
  font:
    14px/1.4 system-ui,
    sans-serif;
}
.wheel-heading {
  display: flex;
  justify-content: flex-end;
  align-items: center;
  gap: 12px;
  margin-bottom: 10px;
  min-height: 38px;
}
.shortcut {
  padding: 5px 10px;
  background: var(--glass);
  backdrop-filter: blur(16px);
  border: 1px solid #fff9;
  border-radius: 20px;
  box-shadow: 0 2px 12px #2436440a;
}
.wheel {
  position: relative;
  width: 100%;
  aspect-ratio: 1;
  border-radius: 50%;
  background: rgba(245, 250, 253, 0.74);
  backdrop-filter: blur(24px) saturate(1.1);
  box-shadow:
    0 8px 32px #263c501c,
    inset 0 0 0 1px #ffffffdb;
  isolation: isolate;
}
.wheel-sector {
  position: absolute;
  inset: 0;
  width: 100%;
  height: 100%;
  padding: 0;
  background: rgba(255, 255, 255, 0.36);
  color: var(--ink);
  border: 0;
  transition: background-color 110ms ease;
}
.wheel-sector:hover {
  background: rgba(220, 242, 246, 0.86);
}
.wheel-sector:focus-visible {
  outline: 0;
  background: #daeff5;
  box-shadow: inset 0 0 0 5px #167d97;
}
.wheel-sector[aria-pressed="true"] {
  background: rgba(191, 234, 239, 0.83);
}
.sector-content {
  position: absolute;
  transform: translate(-50%, -50%);
  display: flex;
  align-items: center;
  flex-direction: column;
  gap: 6px;
  width: 92px;
  text-align: center;
  pointer-events: none;
}
.sector-name {
  max-width: 88px;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  overflow: hidden;
  overflow-wrap: anywhere;
  font-size: 14px;
  font-weight: 550;
  line-height: 1.15;
}
.equipped-check {
  position: absolute;
  top: 0;
  right: 12px;
  width: 18px;
  height: 18px;
  display: grid;
  place-items: center;
  border-radius: 50%;
  background: #247b89;
  color: #fff;
  font-size: 13px;
}
.wheel-center {
  position: absolute;
  left: 50%;
  top: 50%;
  transform: translate(-50%, -50%);
  width: 36%;
  height: 36%;
  border-radius: 50%;
  border: 1px solid #fff;
  background: rgba(255, 255, 255, 0.56);
  font-size: 17px;
  font-weight: 600;
  box-shadow: inset 0 1px 10px #ffffff80;
}
.wheel-center:hover {
  background: #eefbfd;
}
.wheel-help {
  margin-top: 13px;
  text-align: center;
  background: var(--glass);
  padding: 7px 10px;
  border: 1px solid #fff8;
  border-radius: 12px;
  font-size: 14px;
}
.hud {
  position: fixed;
  left: 50%;
  bottom: 20px;
  transform: translateX(-50%);
  z-index: 30;
  display: grid;
  grid-template-columns: 44px minmax(0, 1fr) 76px 98px 90px;
  align-items: center;
  gap: 10px;
  width: min(640px, calc(100vw - 24px));
  height: 72px;
  padding: 10px 12px;
  border: 1px solid #fff;
  border-radius: 20px;
  background: var(--glass);
  backdrop-filter: blur(22px) saturate(1.1);
  box-shadow: var(--shadow);
  color: var(--ink);
  font:
    14px/1.4 system-ui,
    sans-serif;
  pointer-events: auto;
}
.hud-icon {
  display: grid;
  place-items: center;
  width: 44px;
  height: 44px;
}
.hud-copy {
  min-width: 0;
  overflow: hidden;
}
.hud-name {
  display: block;
  font-size: 16px;
  font-weight: 600;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
.hud button {
  height: 40px;
  width: 100%;
  padding: 8px 4px;
  border: 1px solid var(--line);
  border-radius: 10px;
  white-space: nowrap;
  background: #fff7;
}
.hud button:disabled {
  opacity: 0.42;
  cursor: default;
  background: #e5ecef55;
}
.audio-control {
  position: fixed;
  right: 14px;
  bottom: 100px;
  z-index: 30;
  pointer-events: auto;
}
.mute-audio {
  min-width: 68px;
  min-height: 38px;
  padding: 8px 12px;
  border-radius: 18px;
  border: 1px solid #fff;
  background: var(--glass);
  backdrop-filter: blur(12px);
  box-shadow: 0 2px 12px #263c5017;
}
.toast {
  position: fixed;
  left: 50%;
  bottom: 106px;
  transform: translateX(-50%);
  max-width: calc(100vw - 32px);
  padding: 10px 14px;
  background: var(--glass);
  border: 1px solid var(--line);
  border-radius: 12px;
  z-index: 35;
  box-shadow: var(--shadow);
  font: 14px/1.4 system-ui;
}
.dial-mask,
.dial-rotor {
  position: absolute;
  inset: 0;
  border-radius: 50%;
}
.dial-mask {
  mask-image: conic-gradient(#000 0deg 291deg, transparent 291deg 339deg, #000 339deg 360deg);
}
.dial-rotor {
  will-change: transform;
}
.dial-separator {
  position: absolute;
  inset: 0;
  z-index: 2;
  pointer-events: none;
  filter: drop-shadow(1px 3px 3px #243b462e);
}
.dial-separator svg {
  width: 100%;
  height: 100%;
  overflow: visible;
}
.wheel {
  touch-action: none;
  user-select: none;
}
.wheel-sector {
  touch-action: none;
  cursor: grab;
}
.wheel-sector:disabled {
  opacity: 1;
  cursor: default;
}
.wheel-center {
  z-index: 3;
}
.quick-settings {
  margin-bottom: 16px;
}
.cursor-cue {
  position: fixed;
  z-index: 20;
  pointer-events: none;
  width: 48px;
  height: 48px;
  display: grid;
  place-items: center;
  border-radius: 50%;
  background: rgba(255, 255, 255, 0.74);
  border: 1px solid #ffffffd9;
  backdrop-filter: blur(9px);
  box-shadow: 0 3px 12px #243d4f14;
}
.highlight {
  position: fixed;
  z-index: 15;
  border: 2px solid #388da0;
  background: #5fc0cd15;
  box-shadow: 0 0 0 2px #fff8;
  border-radius: 4px;
  pointer-events: none;
}
.stage {
  position: fixed;
  inset: 0;
  z-index: 1;
  overflow: hidden;
  pointer-events: none;
}
@media (max-width: 620px) {
  .art-dialog .tool-grid {
    grid-template-columns: repeat(2, minmax(0, 1fr));
  }
  .art-app {
    padding: 16px;
  }
  .hud {
    grid-template-columns: 36px minmax(0, 1fr) 70px 88px 80px;
    gap: 6px;
    padding: 8px;
    bottom: 10px;
  }
  .hud-icon {
    width: 36px;
  }
  .toolbar {
    flex-wrap: wrap;
  }
  .toolbar select {
    max-width: none;
    width: 100%;
  }
}
@media (max-width: 400px) {
  .sector-content {
    width: 72px;
    gap: 3px;
  }
  .sector-content svg {
    width: 30px;
    height: 30px;
  }
  .sector-name {
    max-width: 68px;
  }
  .equipped-check {
    right: 3px;
  }
  .wheel-center {
    font-size: 15px;
  }
  .wheel-help {
    font-size: 14px;
  }
  .hud {
    max-width: calc(100vw - 12px);
  }
}
@media (prefers-reduced-motion: reduce) {
  * {
    transition: none !important;
    scroll-behavior: auto !important;
  }
}
@media (prefers-contrast: more) {
  :host {
    --glass: #fff;
    --line: #687d8d;
  }
  .wheel,
  .wheel-sector {
    background: #fff;
  }
  .wheel-sector[aria-pressed="true"] {
    background: #cfedf3;
  }
}
@media (forced-colors: active) {
  .wheel-sector {
    background: Canvas;
    color: CanvasText;
  }
  .wheel-sector[aria-pressed="true"] {
    background: Highlight;
    color: HighlightText;
  }
  .wheel-sector:focus-visible {
    outline: 3px solid Highlight;
  }
  .hud,
  .art-dialog,
  .wheel {
    border: 1px solid CanvasText;
    box-shadow: none;
  }
}

@media (max-width: 460px) {
  .hud {
    height: 106px;
    grid-template-columns: 38px minmax(0, 1fr) minmax(0, 1fr);
    grid-template-rows: 36px 40px;
    gap: 8px;
    width: calc(100vw - 16px);
  }
  .hud-copy {
    grid-column: 2/4;
  }
  .hud-switch {
    grid-column: 1;
  }
  .hud button {
    font-size: 14px;
  }
  .hud-switch {
    min-width: 0;
  }
  .hud {
    grid-template-columns: repeat(3, minmax(0, 1fr));
  }
  .audio-control {
    bottom: 128px;
  }
  .toast {
    bottom: 174px;
  }
}
`;function Q(e){if(!(e instanceof HTMLElement)||!e.isConnected||["HTML","BODY"].includes(e.tagName)||oe(e))return!1;let t=e.getBoundingClientRect(),o=getComputedStyle(e);return o.visibility!=="hidden"&&o.display!=="none"&&t.width>=12&&t.height>=12&&t.width<=1200&&t.height<=800&&t.bottom>0&&t.right>0&&t.left<innerWidth&&t.top<innerHeight}function ve(e,t){let o=document.elementFromPoint(e,t);for(let i=0;i<12&&o?.shadowRoot;i++){let n=o.shadowRoot.elementFromPoint(e,t);if(!n||n===o)break;o=n}if(Q(o))return o;return null}function be(e=100){let t=[],o=0,i=(n)=>{for(let s of n.children){if(++o>3000||t.length>=e)return;if(oe(s))continue;if(Q(s)&&s.matches("p,h1,h2,h3,article,button,a,li,[role=article],[role=listitem],img")){t.push(s);continue}if(s.shadowRoot)i(s.shadowRoot);else i(s)}};return i(document.body),t}class re{version;events=[];correlation=0;constructor(e=()=>"unknown"){this.version=e}write(e,t,o=0){if(e==="effect.load.started")this.correlation++;this.events.push({timestamp:Date.now(),event:e,effectId:t,effectVersion:this.version(t),runtimeVersion:"0.3.0",correlationId:this.correlation,durationMs:Math.round(o)}),this.events=this.events.slice(-100)}report(){return[...this.events]}clear(){this.events=[]}}var Pe={muted:!1,volume:0.2,effects:!0,navigation:!0},z=(e,t,o,i)=>Number.isFinite(e)?Math.min(o,Math.max(t,e)):i;class ae{factory;context;master;compressor;noise;preferences={...Pe};voices=new Set;owners=new Set;unlocked=!1;disposed=!1;unavailable=!1;contexts=0;lastTick=-1/0;constructor(e=()=>new AudioContext){this.factory=e}configure(e){if(this.preferences={muted:!!e.muted,volume:z(e.volume,0,1,0.2),effects:!!e.effects,navigation:!!e.navigation},this.context&&this.master){let t=this.context.currentTime;this.master.gain.cancelScheduledValues(t),this.master.gain.setValueAtTime(this.preferences.muted?0:this.preferences.volume,t)}for(let t of this.voices)if(this.preferences.muted||this.preferences.volume===0||t.kind==="effect"&&!this.preferences.effects||t.kind==="navigation"&&!this.preferences.navigation)this.stopVoice(t,this.preferences.muted||this.preferences.volume===0)}unlock(){if(this.disposed||this.preferences.muted||this.preferences.volume===0)return;let e;try{if(!this.context){let t=e=this.factory();this.contexts++;let o=t.createGain(),i=t.createDynamicsCompressor();i.threshold.value=-15,i.knee.value=18,i.ratio.value=4,i.attack.value=0.004,i.release.value=0.15,o.connect(i),i.connect(t.destination),this.context=t,this.master=o,this.compressor=i,e=void 0,this.configure(this.preferences)}if(this.unlocked=!0,this.unavailable=!1,this.context.state==="suspended")this.context.resume().catch(()=>{this.unavailable=!0,this.stopAll()})}catch{if(e)e.close().catch(()=>{});this.unavailable=!0,this.unlocked=!1}}scope(e,t="effect"){if(this.disposed)return{play:()=>{},stop:()=>{}};let o={};this.owners.add(o);let i=!1;return{play:(n,s)=>{if(i)return;this.play(o,e,n,t,s)},stop:()=>{if(i)return;i=!0,this.owners.delete(o);for(let n of this.voices)if(n.owner===o)this.stopVoice(n)}}}play(e,t,o,i,n={}){let s=this.context;if(this.disposed||!this.unlocked||!s||s.state==="closed"||this.unavailable||this.preferences.muted||this.preferences.volume===0||i==="effect"&&!this.preferences.effects||i==="navigation"&&!this.preferences.navigation)return;let r=Object.hasOwn(t,o)?t[o]:void 0;if(!r||!Array.isArray(r.layers))return;if(i==="navigation"&&o==="tick"){if(s.currentTime-this.lastTick<0.08)return;this.lastTick=s.currentTime}for(let c of r.layers.slice(0,8)){if(this.voices.size>=8)break;if(!["noise","sine","triangle","square"].includes(c.wave))continue;let d,h=[];try{let l=s.currentTime+z(n.delay,0,5,0)+z(c.delay,0,2,0),x=z(c.duration,0.008,1.5,0.1),y=z(n.pitch,0.75,1.25,1),C=z(n.strength,0,1.5,1),T=z(c.frequency*y,30,12000,440);if(c.wave==="noise"){let f=s.createBufferSource();f.buffer=this.noise??=this.createNoise(s),d=f}else{let f=s.createOscillator();if(f.type=c.wave,f.frequency.setValueAtTime(T,l),c.endFrequency!==void 0)f.frequency.exponentialRampToValueAtTime(z(c.endFrequency*y,30,12000,T),l+x);d=f}h.push(d);let w=s.createBiquadFilter();w.type="lowpass",w.frequency.setValueAtTime(z(c.cutoff,150,12000,c.wave==="noise"?Math.min(5000,T*3):1e4),l),d.connect(w),h.push(w);let k=s.createGain(),O=Math.min(x*0.4,z(c.attack,0.002,0.2,0.004)),P=z(c.gain*C,0,0.18,0.03);k.gain.setValueAtTime(0,l),k.gain.linearRampToValueAtTime(P,l+O),k.gain.exponentialRampToValueAtTime(0.0001,l+x),k.gain.setValueAtTime(0,l+x+0.005),w.connect(k),h.push(k);let S=s.createStereoPanner();S.pan.setValueAtTime(z(n.pan,-1,1,0),l),k.connect(S),S.connect(this.master),h.push(S);let L={source:d,gain:k,nodes:h,owner:e,kind:i,stopping:!1,start:l};this.voices.add(L),d.onended=()=>this.release(L),d.start(l),d.stop(l+x+0.01)}catch{if(d){for(let l of this.voices)if(l.source===d)this.voices.delete(l);try{d.stop()}catch{}}for(let l of h)try{l.disconnect()}catch{}}}}createNoise(e){let t=e.createBuffer(1,Math.ceil(e.sampleRate*1.6),e.sampleRate),o=t.getChannelData(0),i=41041;for(let n=0;n<o.length;n++)i=Math.imul(i,1664525)+1013904223|0,o[n]=(i>>>0)/4294967296*2-1;return t}release(e){this.voices.delete(e),e.source.onended=null;for(let t of e.nodes)try{t.disconnect()}catch{}}stopVoice(e,t=!1){let o=this.context;if(!o){this.release(e);return}if(t||=o.state!=="running"||e.start>o.currentTime,e.stopping&&!t)return;e.stopping=!0;let i=o.currentTime;try{if(t){e.source.stop(i),this.release(e);return}let n=e.gain.gain;if(typeof n.cancelAndHoldAtTime==="function")n.cancelAndHoldAtTime(i);else n.cancelScheduledValues(i),n.setValueAtTime(Math.min(0.18,Math.max(0,n.value)),i);n.linearRampToValueAtTime(0,i+0.02),e.source.stop(i+0.025)}catch{this.release(e)}}stopAll(){for(let e of this.voices)this.stopVoice(e)}suspend(){for(let e of this.voices)this.stopVoice(e,!0);if(this.unlocked=!1,this.context?.state==="running")this.context.suspend().catch(()=>{})}dispose(){if(this.disposed)return;this.disposed=!0;for(let t of this.voices)this.stopVoice(t,!0);this.owners.clear(),this.unlocked=!1;let e=this.context;if(e)e.close().catch(()=>{}).finally(()=>{for(let t of this.voices)for(let o of t.nodes)try{o.disconnect()}catch{}this.voices.clear(),this.master?.disconnect(),this.compressor?.disconnect(),this.noise=void 0})}report(){return{state:this.disposed?"disposed":this.unavailable?"unavailable":this.context?.state??"uninitialized",muted:this.preferences.muted,volume:this.preferences.volume,voices:this.voices.size,scopes:this.owners.size,contexts:this.contexts,noiseBuffers:this.noise?1:0}}}var Ae="a,button,input,textarea,select,option,summary,label,iframe,object,embed,[contenteditable]:not([contenteditable=false]),[role=button],[role=link],[role=checkbox],[role=radio],[role=switch],[role=slider],[role=textbox],[role=combobox],[role=listbox],[role=option],[role=menuitem],[role=tab],[role=treeitem],[role=spinbutton],audio,video",qe=1800;class de{onOpen;unlock;resources=new N;enabled=!1;disposed=!1;ownsPress=!1;hold;constructor(e,t){this.onOpen=e;this.unlock=t;let o={capture:!0};this.resources.listen(window,"pointerdown",(i)=>this.down(i),o),this.resources.listen(window,"mousedown",(i)=>this.down(i),o),this.resources.listen(window,"pointermove",(i)=>this.move(i),o),this.resources.listen(window,"mousemove",(i)=>this.move(i),o);for(let i of["pointerup","mouseup"])this.resources.listen(window,i,(n)=>{if(n.button!==1)return;if(this.ownsPress)this.suppress(n);this.cancel()},o);this.resources.listen(window,"auxclick",(i)=>{if(i.button!==1||!this.ownsPress)return;this.suppress(i),this.ownsPress=!1,this.cancel()},o);for(let i of["blur","pagehide","pointercancel"])this.resources.listen(window,i,()=>this.cancel(),o);this.resources.listen(document,"visibilitychange",()=>{if(document.hidden)this.cancel()})}configure(e){if(this.enabled=e&&!this.disposed,!this.enabled)this.cancel()}suppress(e){e.preventDefault(),e.stopImmediatePropagation()}eligible(e){let t=e.composedPath().filter((o)=>o instanceof Element);if(t.some((o)=>o.matches(Ae)))return!1;return!t.some((o)=>o.hasAttribute("data-art-root")||o.hasAttribute("data-art-gesture"))}down(e){if(e.button!==1)return;if(e.type==="mousedown"&&this.ownsPress){this.suppress(e);return}if(this.cancel(),this.ownsPress=!1,!this.enabled||e.shiftKey||e.ctrlKey||e.altKey||e.metaKey||!this.eligible(e))return;this.ownsPress=!0,this.suppress(e),this.unlock();let t=document.createElement("div");t.dataset.artGesture="",t.setAttribute("aria-hidden","true");let o=Math.max(4,Math.min(Math.max(4,innerWidth-48),e.clientX+38)),i=Math.max(4,Math.min(Math.max(4,innerHeight-48),e.clientY+38));t.style.cssText=`all:initial;position:fixed;pointer-events:none;z-index:2147483647;width:40px;height:40px;left:${o}px;top:${i}px;border-radius:50%;border:1px solid #ffffffb8;box-shadow:0 3px 14px #29405625;`,document.documentElement.append(t);let n={x:e.clientX,y:e.clientY,started:performance.now(),frame:0,ring:t};this.hold=n;let s=(r)=>{if(this.hold!==n)return;let c=Math.max(0,Math.min(1,(r-n.started)/qe));if(t.style.background=`radial-gradient(circle,#eef5f8f5 57%,transparent 59%),conic-gradient(#79afb7 ${c*360}deg,#dae3e980 0deg)`,c>=1)this.cancel(),this.onOpen();else n.frame=requestAnimationFrame(s)};s(n.started)}move(e){if(!this.hold)return;if(!(e.buttons&4)||Math.hypot(e.clientX-this.hold.x,e.clientY-this.hold.y)>12)this.cancel()}cancel(){if(!this.hold)return;cancelAnimationFrame(this.hold.frame),this.hold.ring.remove(),this.hold=void 0}dispose(){if(this.disposed)return;this.disposed=!0,this.enabled=!1,this.cancel(),this.ownsPress=!1,this.resources.dispose()}}class ce{stage;inputAllowed;changed;diagnostics;audio;scope;instance;abort;generation=0;effectId="";state="idle";started=0;constructor(e,t,o,i,n){this.stage=e;this.inputAllowed=t;this.changed=o;this.diagnostics=i;this.audio=n}get resources(){return this.scope?.size??0}end(e="user"){++this.generation,this.abort?.abort(),this.abort=void 0;try{this.instance?.stop(e)}catch{this.diagnostics.write("effect.cleanup.failed",this.effectId)}try{this.instance?.dispose()}catch{this.diagnostics.write("effect.cleanup.failed",this.effectId)}if(this.scope?.dispose(),this.scope=void 0,this.instance=void 0,this.effectId)this.diagnostics.write("effect.stop.completed",this.effectId);this.effectId="",this.state="idle",this.changed()}run(e,t,o,i){this.end("replacement");let n=this.generation;this.effectId=e.id,this.state="starting",this.abort=new AbortController;let s=()=>{if(n!==this.generation)return;this.diagnostics.write("effect.start.failed",e.id),this.end("error"),this.state="failed",this.changed()},r=new N(s);this.scope=r;let c=r.node(this.stage()),d=performance.now();this.started++,this.diagnostics.write("effect.start.started",e.id);try{let h=e.audioProfile?this.audio?.scope(e.audioProfile):void 0;if(h)r.own(()=>h.stop());h?.play("activate"),this.instance=t.create({audio:h,document:o.document,signal:this.abort.signal,resources:r,overlay:c,inputAllowed:this.inputAllowed,finish:()=>{if(n===this.generation)this.end("timeout")}});let l=this.instance.start(o,i);if(Promise.resolve(l).then(()=>{if(n!==this.generation)return;this.state=e.lifetime.class==="repeatable"?"playing":"continuous",this.diagnostics.write("effect.start.completed",e.id,performance.now()-d),this.changed()}).catch(s),e.lifetime.class==="repeatable")r.timeout(()=>{if(n===this.generation)this.end("timeout")},Math.max(e.lifetime.animationMs+e.lifetime.residueMs,i.duration*1000));let x=o.kind==="element"?[o.element]:o.kind==="document"?o.elements:[];if(x.length){let y=x.map((w)=>({element:w,rect:w.getBoundingClientRect()})),C=()=>y.some(({element:w,rect:k})=>{if(!w.isConnected)return!0;let O=w.getBoundingClientRect();return["left","top","width","height"].some((P)=>Math.abs(O[P]-k[P])>1)}),T=new MutationObserver((w)=>{if(C()||w.some((k)=>k.type!=="attributes"&&x.some((O)=>O.contains(k.target))))this.end("navigation")});if(T.observe(o.document.body,{childList:!0,subtree:!0,characterData:!0,attributes:!0,attributeFilter:["class","style","hidden"]}),r.own(()=>T.disconnect()),typeof ResizeObserver<"u"){let w=new ResizeObserver(()=>{if(C())this.end("navigation")});for(let k of x)w.observe(k);r.own(()=>w.disconnect())}}this.changed()}catch{s()}}}class we{modules=new Map;epoch=0;menuEpoch=0;host;shadow;shell;equipped;state="unequipped";menu;menuScope;restoreFocus=null;catalogPosition;hud;cue;outline;candidate=null;pointer;resumeContinuous=!1;diagnostics=new re((e)=>I.find((t)=>t.id===e)?.version??"unknown");ready=Promise.resolve();audio=new ae;hold=new de(()=>{this.showWheel()},()=>this.audio.unlock());execution=new ce(()=>this.node("stage"),()=>!this.menu&&this.state!=="suspended",()=>this.updateHUD(),this.diagnostics,this.audio);constructor(){this.ready=this.refreshPreferences();for(let e of["popstate","hashchange"])window.addEventListener(e,()=>this.shutdown());if("navigation"in window)window.navigation.addEventListener("navigate",()=>this.shutdown());window.addEventListener("pagehide",(e)=>{if(this.shutdown(),!e.persisted)this.hold.dispose(),this.audio.dispose()})}async refreshPreferences(){let e=await U();this.audio.configure(e.audio),this.hold.configure(e.middleHold),this.updateMute()}register(e,t){if(!I.some((o)=>o.id===e)||t.sdkVersion!=="1.0"||typeof t.create!=="function")throw Error("INVALID_MODULE");if(!this.modules.has(e))this.modules.set(e,t)}surface(){if(this.shadow&&this.host?.isConnected)return this.shadow;this.host=document.createElement("div"),this.host.dataset.artRoot="",this.host.style.cssText="all:initial!important;position:fixed!important;inset:0!important;z-index:2147483647!important;pointer-events:none!important;display:block!important;transform:none!important;",this.shadow=this.host.attachShadow({mode:"open"});let e=document.createElement("style");e.textContent=ge,this.shadow.append(e),this.shadow.addEventListener("pointerdown",(o)=>{if(o.isTrusted)this.audio.unlock()},!0),this.shadow.addEventListener("keydown",(o)=>{if(o.isTrusted&&["Enter"," "].includes(o.key))this.audio.unlock()},!0),document.documentElement.append(this.host);let t=new N(()=>this.putAway("error"));return this.shell=t,t.listen(window,"keydown",(o)=>this.key(o),{capture:!0}),t.listen(window,"resize",()=>this.geometry()),t.listen(document,"scroll",()=>{if(!this.menu)this.geometry()},{capture:!0,passive:!0}),t.listen(document,"visibilitychange",()=>{if(!this.equipped)return;if(document.hidden)this.hold.cancel(),this.audio.suspend(),this.resumeContinuous=this.execution.state==="continuous",this.state="suspended",this.execution.end("shutdown"),this.syncInput();else{if(this.state=this.equipped.descriptor.scope==="element"?"targeting":"equipped",this.syncInput(),this.resumeContinuous&&this.equipped.descriptor.lifetime.class==="continuous")this.executeAutomatic();this.resumeContinuous=!1}this.updateHUD()}),this.shadow}node(e,t=this.surface()){let o=a("div",e);return t.appendChild(o),o}releaseShell(){if(this.equipped||this.menu)return;this.shell?.dispose(),this.shell=void 0,this.host?.remove(),this.host=void 0,this.shadow=void 0}shutdown(){this.closeMenu(!1),this.putAway("navigation"),this.hold.cancel(),this.audio.suspend(),this.catalogPosition=void 0,this.releaseShell()}putAway(e="user"){if(++this.epoch,this.hold.cancel(),this.resumeContinuous=!1,this.execution.end(e),this.audio.stopAll(),this.equipped?.resources.dispose(),this.equipped=void 0,this.hud=void 0,this.cue=void 0,this.outline=void 0,this.candidate=null,this.pointer=void 0,this.state=e==="replacement"?"switching":"unequipped",this.host)this.host.removeAttribute("data-equipped");this.refreshCatalogSelection(),this.releaseShell()}closeMenu(e=!0){if(++this.menuEpoch,this.menuScope?.dispose(),this.menuScope=void 0,this.menu=void 0,this.host?.removeAttribute("data-menu"),this.syncInput(),e)if(this.restoreFocus?.isConnected)this.restoreFocus.focus({preventScroll:!0});else this.hud?.querySelector("button")?.focus({preventScroll:!0});this.restoreFocus=null,this.releaseShell()}openMenu(e){this.hold.cancel(),this.closeMenu(!1),this.surface(),this.menu=e,this.host.dataset.menu=e,this.restoreFocus=this.shadow?.activeElement??document.activeElement;let t=new N(()=>this.closeMenu());this.menuScope=t;let o=++this.menuEpoch,i=t.node(this.node("menu-scrim"));return t.listen(i,"pointerdown",(n)=>{n.preventDefault(),n.stopImmediatePropagation()}),t.listen(i,"click",(n)=>{n.preventDefault(),n.stopImmediatePropagation(),this.closeMenu()}),this.syncInput(),{resources:t,epoch:o,container:this.node("menu-layer")}}async assignedShortcut(){try{let e=await chrome.runtime.sendMessage({type:"shortcut"});return j(e)&&typeof e.shortcut==="string"?e.shortcut:""}catch{return""}}async showWheel(){if(await this.ready,this.menu==="wheel"){this.closeMenu();return}let{resources:e,epoch:t,container:o}=this.openMenu("wheel");e.node(o);let[i,n]=await Promise.all([U(),this.assignedShortcut()]);if(t!==this.menuEpoch)return;let r=[...new Set([...i.favorites,...i.recent,...I.map((d)=>d.id)])].map((d)=>I.find((h)=>h.id===d)),c=me(r,this.equipped?.descriptor.id,n,(d)=>{this.choose(d,i.options)},()=>{this.showCatalog()},()=>this.closeMenu(),e,this.audio.scope(fe,"navigation"));o.append(c),c.querySelector(".wheel-sector[tabindex='0']")?.focus(),this.updateHUD()}async showCatalog(){await this.ready;let{resources:e,epoch:t,container:o}=this.openMenu("catalog");e.node(o);let i=this.node("art-dialog",o);i.setAttribute("role","dialog"),i.setAttribute("aria-modal","true"),i.setAttribute("aria-label","Choose a tool");let n=a("div");if(i.append(n),await ne(n,(r,c)=>this.choose(r,c),{wheel:()=>{this.showWheel()},close:()=>this.closeMenu(),stop:()=>this.putAway(),diagnostics:async()=>this.report(),clearDiagnostics:()=>this.diagnostics.clear(),equipped:()=>this.equipped?.descriptor.id,changed:()=>{this.refreshPreferences()}}),t!==this.menuEpoch)return;let s=n.querySelector(".brand");he(i,s,e,this.catalogPosition,(r)=>{this.catalogPosition=r}),n.querySelector("input")?.focus()}refreshCatalogSelection(){if(!this.shadow)return;let e=this.shadow.querySelector(".footer .put-away");if(e)e.disabled=!this.equipped;for(let t of this.shadow.querySelectorAll(".tool[data-id]")){let o=t.dataset.id===this.equipped?.descriptor.id;t.setAttribute("data-equipped",String(o)),t.querySelector(".tool-use")?.setAttribute("aria-pressed",String(o))}}async choose(e,t){let o=I.find((c)=>c.id===e);if(!o)throw Error("UNKNOWN_EFFECT");let i=++this.epoch;if(await this.ready,i!==this.epoch)return;this.closeMenu(!1),this.putAway("replacement"),this.surface();let n=++this.epoch,s=_(t);s.reducedMotion||=matchMedia("(prefers-reduced-motion: reduce)").matches;let r=new N(()=>this.putAway("error"));this.equipped={descriptor:o,options:s,resources:r},this.state="loading",this.host.dataset.equipped=e,this.createHUD(r),this.diagnostics.write("effect.load.started",e);try{if(!this.modules.has(e)){let d=await chrome.runtime.sendMessage({type:"load",id:e});if(n!==this.epoch)return;if(!d?.ok||!this.modules.has(e))throw Error("LOAD_FAILED")}if(n!==this.epoch)return;if(this.diagnostics.write("effect.load.completed",e),this.state=document.hidden?"suspended":o.scope==="element"?"targeting":"equipped",o.scope==="element")this.targeting(r);else this.executeAutomatic();let c=await U();if(n!==this.epoch)return;c.recent=[e,...c.recent.filter((d)=>d!==e)].slice(0,16);try{await chrome.storage.local.set({preferences:c})}catch{}this.updateHUD()}catch{if(n!==this.epoch)return;this.diagnostics.write("effect.load.failed",e),this.execution.end("error"),this.state="failed",this.updateHUD()}}createHUD(e){let t=e.node(this.node("hud"));t.setAttribute("role","toolbar"),t.setAttribute("aria-label","Equipped tool"),this.hud=t;let o=a("span","hud-icon");o.innerHTML=G(this.equipped.descriptor,38);let i=a("div","hud-copy"),n=a("strong","hud-name",this.equipped.descriptor.name);n.title=this.equipped.descriptor.name,i.append(n);let s=E("Switch",()=>{this.showWheel()},"hud-switch"),r=E("End effect",()=>this.execution.end(),"end-effect"),c=E("Put away",()=>this.putAway(),"put-away");t.append(o,i,s,r,c),e.node(this.node("audio-control")).append(E("Mute",()=>{this.audio.unlock(),U().then(async(h)=>{h.audio.muted=!h.audio.muted,this.audio.configure(h.audio),this.audio.unlock(),this.updateMute(),await chrome.storage.local.set({preferences:h})}).catch(()=>{})},"mute-audio")),this.updateMute(),this.updateHUD(),this.assignedShortcut().then((h)=>{if(!e.closed)s.title=h?`Open action wheel (${h})`:"Open action wheel; assign a shortcut in extension settings"})}updateHUD(){if(!this.hud||!this.equipped)return;let e=this.hud.querySelector(".end-effect");if(e.disabled=["idle","failed"].includes(this.execution.state),this.state==="failed"||this.execution.state==="failed")this.notify("Tool could not run. Switch tools to retry.")}updateMute(){let e=this.shadow?.querySelector(".mute-audio");if(!e)return;let t=this.audio.report().muted;e.textContent=t?"Unmute":"Mute",e.setAttribute("aria-label",t?"Unmute all sounds":"Mute all sounds"),e.setAttribute("aria-pressed",String(t))}notify(e){if(!this.equipped||this.shadow?.querySelector(".toast"))return;let t=this.equipped.resources.node(this.node("toast"));t.setAttribute("role","status"),t.textContent=e,this.equipped.resources.timeout(()=>t.remove(),4000)}syncInput(){let e=!!this.menu||this.state==="suspended"||this.state==="loading";if(this.cue)this.cue.hidden=e||!this.pointer;if(this.outline)this.outline.hidden=e||!this.candidate}mark(e){if(this.candidate=e,e&&this.outline)le(this.outline,e.getBoundingClientRect());this.syncInput()}resolve(e,t){return ve(e,t)}targeting(e){let t=e.node(this.node("highlight")),o=e.node(this.node("cursor-cue"));o.innerHTML=G(this.equipped.descriptor,32),this.outline=t,this.cue=o,this.syncInput();let i=(n)=>{if(this.menu||this.state!=="targeting")return!1;return!n.composedPath().some((c)=>c instanceof Element&&c.hasAttribute("data-art-root"))};e.listen(window,"pointermove",(n)=>{if(!i(n)){this.pointer=void 0,this.mark(null);return}let s=n;this.pointer={x:s.clientX,y:s.clientY};let r=pe(s.clientX,s.clientY);o.style.left=`${r.x}px`,o.style.top=`${r.y}px`,this.mark(this.resolve(s.clientX,s.clientY))},{capture:!0,passive:!0});for(let n of["pointerdown","pointerup","mousedown","mouseup","dblclick"])e.listen(window,n,(s)=>{if(!i(s)||s.button!==0)return;if(s.preventDefault(),s.stopImmediatePropagation(),n==="pointerdown"&&s.isTrusted)this.audio.unlock()},{capture:!0});e.listen(window,"click",(n)=>{let s=n;if(!i(n)||s.button!==0||s.detail===0)return;if(n.preventDefault(),n.stopImmediatePropagation(),n.isTrusted)this.audio.unlock();this.execution.end("replacement"),this.use(this.resolve(s.clientX,s.clientY),s.clientX,s.clientY)},{capture:!0}),e.listen(window,"pointerout",(n)=>{if(n.relatedTarget)return;this.pointer=void 0,this.mark(null)})}use(e,t,o){let i=this.equipped;if(!i||this.menu||this.state!=="targeting")return;if(this.execution.end("replacement"),!Q(e)||e.ownerDocument!==document){this.diagnostics.write("effect.target.invalid",i.descriptor.id),this.mark(null);return}this.mark(null),this.execution.run(i.descriptor,this.modules.get(i.descriptor.id),{kind:"element",document,element:e,x:t,y:o},i.options)}executeAutomatic(){let e=this.equipped;if(!e||this.state==="suspended")return;let t=e.descriptor.scope==="document"?{kind:"document",document,elements:be(12)}:{kind:"viewport",document};if(t.kind==="document"&&!t.elements.length){this.execution.end(),this.notify("No visible targets. Scroll to content, then reselect the tool.");return}this.execution.run(e.descriptor,this.modules.get(e.descriptor.id),t,e.options)}geometry(){if(!this.equipped)return;if(this.mark(null),this.equipped.descriptor.scope!=="viewport")this.execution.end("navigation");this.syncInput()}key(e){if(e.key==="Escape"){if(e.preventDefault(),e.stopImmediatePropagation(),this.menu)this.closeMenu();else this.putAway();return}if(this.menu){let t=this.shadow?.querySelector('[role="dialog"]');if(t)ue(t,e,this.shadow?.activeElement??null);return}}report(){return{state:this.state,equipped:this.equipped?.descriptor.id??null,menu:this.menu??null,invocation:this.execution.state,invocationsStarted:this.execution.started,resources:this.execution.resources,sessionResources:this.equipped?.resources.size??0,loaded:[...this.modules.keys()],audio:this.audio.report(),events:this.diagnostics.report()}}clearDiagnostics(){this.diagnostics.clear()}}if(!globalThis.__angerReliefToyV1){let e=new we;globalThis.__angerReliefToyV1=e,chrome.runtime.onMessage.addListener((t,o,i)=>{if(o.id!==chrome.runtime.id||!j(t))return!1;if(["select","show"].includes(String(t.type))&&(document.contentType!=="text/html"||!(document.body instanceof HTMLElement)))return i({ok:!1,error:"UNSUPPORTED_DOCUMENT"}),!1;if(t.type==="preferences-changed")return e.refreshPreferences().then(()=>i({ok:!0})),!0;if(t.type==="select"&&typeof t.id==="string")return e.choose(t.id,t.options).then(()=>i({ok:!0})).catch(()=>i({ok:!1})),!0;if(t.type==="show")return(t.mode==="wheel"?e.showWheel():e.showCatalog()).then(()=>i({ok:!0})).catch(()=>i({ok:!1})),!0;if(t.type==="stop")e.putAway(),i({ok:!0});if(t.type==="report")i(e.report());if(t.type==="clear-diagnostics")e.clearDiagnostics(),i({ok:!0});if(t.type==="ping")i({ok:!0});return!1})}})();
